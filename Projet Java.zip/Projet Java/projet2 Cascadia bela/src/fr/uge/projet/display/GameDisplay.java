package fr.uge.projet.display;
/**
 * Interface representing the game display.
 * Classes implementing this interface will define how the game is visually displayed.
 */
public interface GameDisplay {
}
