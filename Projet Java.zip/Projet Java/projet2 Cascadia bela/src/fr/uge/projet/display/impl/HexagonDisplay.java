package fr.uge.projet.display.impl;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.github.forax.zen.*;

import fr.uge.projet.display.GameDisplay;
import fr.uge.projet.display.ImageDrawer;
import fr.uge.projet.engine.AnimalType;
import fr.uge.projet.engine.Tile;


public class HexagonDisplay implements GameDisplay {

  private final ApplicationContext context;
  private final Map<String, BufferedImage> imageMap = new HashMap<>(); // Store images by name
  private int currentRow = 1;
  private int currentCol = 1;
  private ImageDrawer imageHandler; // Stores the selected options
  private BufferedImage resizedImage;
  private boolean showOptions = false;


  private double apothem;

  public HexagonDisplay(ApplicationContext context) {
    imageHandler = new ImageDrawer(context);
    ScreenInfo screenInfo = context.getScreenInfo();
    this.context = context;
    try {
      imageHandler.loadImagesFromFolder("img/hexagon/", imageMap);
    } catch (IOException e) {
      System.err.println("Failed to load images from folder: " + e.getMessage());
      return;
    }
    BufferedImage originalImage = imageHandler.getImage("background", imageMap);
    this.resizedImage = imageHandler.resizeImage(originalImage, screenInfo.height(), screenInfo.width());
  }

  public String processTableString(String tableString, String tableString2) {
    if (tableString == null) {
      throw new IllegalArgumentException("tableString must have at least 2 elements");
    }

    if (tableString.equals(tableString2)) {
      return tableString;
    } else {
      return tableString + "+" + tableString2;
    }
  }


  public void drawHexagon(Tile[][] tile, double apothem, int x, int y) {

    double side = (2 * apothem) / Math.sqrt(3);
    int cy = (int) (side + ((side * 3 * y) / 2)); // Adjust vertical position for staggered rows
    int cx = (int) apothem * (x) + (int) apothem;
    double radius = side;
    Polygon hexagon = new Polygon();
    for (int i = 0; i < 6; i++) {
      double angleRad = Math.toRadians(90 + (60 * i));
      int vx = (int) Math.round(cx + radius * Math.cos(angleRad));
      int vy = (int) Math.round(cy + radius * Math.sin(angleRad));
      hexagon.addPoint(vx, vy);
    }
    context.renderFrame(graphics -> {

      ScreenInfo screenInfo = context.getScreenInfo();
      int screenWidth = screenInfo.width();
      int screenHeight = screenInfo.height() - 150;
      int rows = tile.length;
      int cols = tile[0].length;
      int factor = Math.min(screenWidth / Math.max(1, cols), screenHeight / Math.max(1, rows));
      factor = Math.max(factor, 10); // Ensure minimum visibility
      int screenX = cx - 10;
      int screenY = cy;
      int offset = 0;
      if (tile[y][x] != null) {

        //imageHandler.drawImage(tile[y][x].getAreaType().get(0).name(), cx-(int)apothem, cy-(int)side, (int)apothem*2, (int)side*2, imageMap);

        int pivotCount = tile[y][x].getnumberOfPivots();
        double baseAngleDeg = 60.0; // For example, 60° per pivot
        double totalAngleDeg = baseAngleDeg * pivotCount;
        double totalAngleRad = Math.toRadians(totalAngleDeg);
        String imageName = processTableString(tile[y][x].getAreaType().get(0).name(), tile[y][x].getAreaType().get(1).name()); //  tile[y][x].getAreaType().get(0).name()
        System.out.println("image	name is : " + imageName);
        BufferedImage originalImage = imageMap.get(imageName);
        var oldTransform = graphics.getTransform();

        try {
          // Move the origin to (cx, cy)
          graphics.translate(cx, cy);
          // Rotate around the new origin
          graphics.rotate(totalAngleRad);
          // Move the image draw position so that the image center is at 0,0
          int drawWidth = (int) (apothem * 2);
          int drawHeight = (int) (side * 2);
          graphics.translate(-drawWidth / 2.0, -drawHeight / 2.0);

          graphics.drawImage(
                  originalImage,
                  0, 0, drawWidth, drawHeight, // destination area
                  0, 0,
                  originalImage.getWidth(), originalImage.getHeight(), // source area
                  null
          );
        } finally {
          graphics.setTransform(oldTransform);
        }
        for (var s : tile[y][x].getAcceptedAnimals()) {
          imageHandler.drawImage(s.name(), (int) screenX + offset, (int) screenY + offset, (int) apothem / 2, (int) apothem / 2, imageMap);
          offset += 10;
        }
        if (tile[y][x].getCurrentlyPlacedAnimal() != null) {
          imageHandler.drawImage(tile[y][x].getCurrentlyPlacedAnimal().name(), (int) (cx - apothem / 2), (int) (cy - apothem / 2), (int) apothem, (int) apothem, imageMap);
        }
      } else {
        graphics.setColor(Color.BLACK);
        graphics.drawPolygon(hexagon);
      }
    });
  }


  public void drawHexagonGrid(Tile[][] array) {
    ScreenInfo screenInfo = context.getScreenInfo();
    int rows = array.length;
    int cols = array[0].length;
    double maxVerticalSpace = (screenInfo.height() * Math.sqrt(3) - 150) / (rows * 2); // Account for staggered rows (height = 1.5x side length)
    double maxHorizontalSpace = screenInfo.width() / ((cols % 2 == 0) ? (cols / 2) : ((cols + 1) / 2)); // Account for hex width = sqrt(3) * side length
    // Apothem is based on the smaller dimension to ensure the grid fits the screen
    double apothem = Math.min(maxVerticalSpace, maxHorizontalSpace) / 2;
    //imageHandler.drawImage("background", 0, 0, (int)(2*apothem * numberHexCol + apothem ), length, imageMap);
    context.renderFrame(graphics -> {
      graphics.drawImage(resizedImage, 0, 0, screenInfo.width(), screenInfo.height(), null);    // Draw the hexagonal grid
    });
    for (int y = 0; y < rows; y++) {
      for (int x = 0; x < cols; x += 2) {
        int xOffset = (y % 2 == 0) ? 0 : 1;
        if ((x + xOffset) < cols) {
          //System.out.println("y : " + y + " x : "+ (x+xOffset));
          drawHexagon(array, apothem, x + xOffset, y);
        }
      }
    }
    highlight(apothem);
    context.renderFrame(graphics -> {
      displayTextBox(screenInfo.width(), screenInfo.height() - 150, graphics);
      displayTextWithSize("choose : A B C D", Color.BLACK, 30, graphics);
    });
  }


  private void displayOptions(List<Tile> arrayOfOptions, List<AnimalType> animalOptions, Graphics2D graphics) {
    ScreenInfo screenInfo = context.getScreenInfo();
    int screenHeight = screenInfo.height() - 150;
    double apothem = ((85 * Math.sqrt(3)) / (1 * 2)) / 2;
    double side = (2 * apothem) / Math.sqrt(3);


    int factor = 150 / 2;
    if (showOptions) {
      int optionX = 50; // Start drawing options in the reserved space
      int optionY = screenHeight + 5; // Start from the top

      int cy = (int) (side + ((side * 3 * optionY) / 2)); // Adjust vertical position for staggered rows
      int cx = (int) apothem * (optionX) + (int) apothem;


      for (var s : arrayOfOptions) {

        imageHandler.drawImage(processTableString(s.getAreaType().get(0).name(), s.getAreaType().get(1).name()), optionX, optionY, (int) apothem * 2, (int) side * 2, imageMap);
        //System.out.println(" name : " + s.getAreaType().get(0).name());
        int offset = 0;
        for (var v : s.getAcceptedAnimals()) {
          imageHandler.drawImage(v.name(), optionX + 10 + offset, optionY + factor / 2 + offset, factor / 3, factor / 3, imageMap);
          offset += 10;
        }
        optionX += factor + 13; // Move down for the next option
      }
      int optionXX = 50; // Start drawing options in the reserved space
      int optionYY = screenHeight + 15 + factor; // Start from the top
      for (var s : animalOptions) {
        imageHandler.drawImage(s.name(), optionXX, optionYY, factor - 20, factor - 20, imageMap);
        optionXX += factor + 10;
      }


    }
  }

  public void toggleOptions(List<Tile> arrayOfOptions, List<AnimalType> animalOptions, Graphics2D graphics) {
    showOptions = true;
    displayOptions(arrayOfOptions, animalOptions, graphics);
    displayTextWithSize("choose : A B C D", Color.BLACK, 30, graphics);
  }

  public void updateHighlight(Tile[][] tile, double apothem, int oldPositionX, int oldPositionY) {
    context.renderFrame(graphics -> {

      double side = (2 * apothem) / Math.sqrt(3);
      int cy = (int) (side + ((side * 3 * oldPositionY) / 2)); // Adjust vertical position for staggered rows
      int cx = (int) apothem * (oldPositionX) + (int) apothem;
      double radius = side;
      Polygon hexagon = new Polygon();
      for (int i = 0; i < 6; i++) {
        double angleRad = Math.toRadians(90 + (60 * i));
        int vx = (int) Math.round(cx + radius * Math.cos(angleRad));
        int vy = (int) Math.round(cy + radius * Math.sin(angleRad));
        hexagon.addPoint(vx, vy);
      }

      if (tile[oldPositionY][oldPositionX] != null) {
        drawHexagon(tile, apothem, oldPositionX, oldPositionY);
      } else if (tile[oldPositionY][oldPositionX] == null) {
        graphics.setClip(hexagon);
        graphics.drawImage(
                resizedImage,
                cx - (int) side, cy - (int) side,
                cx + (int) side, cy + (int) side,
                0, 0,
                resizedImage.getWidth(), resizedImage.getHeight(),
                null
        );
        graphics.setColor(Color.BLACK);
        graphics.drawPolygon(hexagon);
      }

      highlight(apothem);

    });

  }

  public void highlight(double apothem) {
    context.renderFrame(graphics -> {

      double side = (2 * apothem) / Math.sqrt(3);
      int cy = (int) (side + ((side * 3 * getCurrentRow()) / 2)); // Adjust vertical position for staggered rows
      int cx = (int) apothem * (getCurrentCol()) + (int) apothem;
      double radius = side;
      Polygon hexagon = new Polygon();
      for (int i = 0; i < 6; i++) {
        double angleRad = Math.toRadians(90 + (60 * i));
        int vx = (int) Math.round(cx + radius * Math.cos(angleRad));
        int vy = (int) Math.round(cy + radius * Math.sin(angleRad));
        hexagon.addPoint(vx, vy);
      }

      graphics.setColor(new Color(255, 0, 0, 128)); // Translucent red with 50% transparency

      graphics.fillPolygon(hexagon);
      graphics.drawPolygon(hexagon);


    });

  }


  public void displayTextWithSize(String text, Color color, int fontSize, Graphics2D graphics) {
    ScreenInfo screenInfo = context.getScreenInfo();
    int screenWidth = screenInfo.width(); // Reserve space for the options
    int screenHeight = screenInfo.height() - 150;
    graphics.setColor(Color.GREEN);
    graphics.fillRect(screenWidth / 2 + 4, screenHeight + 2, screenWidth / 2 - 10, 143);
    graphics.setColor(color);
    graphics.setFont(new java.awt.Font("Arial", Font.PLAIN, fontSize)); // Ensure using java.awt.Font
    graphics.drawString(text, screenWidth / 2 + 4, screenHeight + 27);

  }

  private void displayTextBox(int screenWidth, int screenHeight, Graphics2D graphics) {
    // graphics.setColor(Color.GREEN);
    // graphics.fillRect(screenX, screenY, factor, factor);
    graphics.setColor(Color.BLACK);
    graphics.setStroke(new BasicStroke(4));
    graphics.drawRect(3, screenHeight, screenWidth - 7, 147);
    graphics.drawRect(3, screenHeight, screenWidth / 2, 147);
  }

  public void moveUp() {
    if (currentRow != 0) {
      currentRow = currentRow - 1;
      currentCol = (currentCol - 1 < 0) ? currentCol + 1 : currentCol - 1;
    }
  }

  public void moveDown(Tile[][] array) {
    if (currentRow != array.length - 1) {
      currentRow = currentRow + 1;
      currentCol = (currentCol - 1 < 0) ? currentCol + 1 : currentCol - 1;
    }

  }

  public void moveLeft() {
    currentCol = (currentCol - 2 < 0) ? currentCol : currentCol - 2;
  }

  public void moveRight(Tile[][] array) {
    currentCol = (currentCol + 2 >= array[0].length) ? currentCol : currentCol + 2;
  }

  public int getCurrentRow() {
    return currentRow;
  }

  public int getCurrentCol() {
    return currentCol;
  }

  public void setCurrentCol(int number) {
    currentCol = number;
  }

  public void setCurrentRow(int number) {
    currentRow = number;
  }


  public ApplicationContext context() {
    return context;
  }
}
