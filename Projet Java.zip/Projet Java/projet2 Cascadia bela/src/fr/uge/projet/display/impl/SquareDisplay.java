package fr.uge.projet.display.impl;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.github.forax.zen.*;

import fr.uge.projet.display.GameDisplay;
import fr.uge.projet.display.ImageDrawer;
import fr.uge.projet.engine.AnimalType;
import fr.uge.projet.engine.Tile;

public class SquareDisplay implements GameDisplay {
  private final ApplicationContext context;
  private final Map<String, BufferedImage> imageMap = new HashMap<>();
  private int currentRow = 0;
  private int currentCol = 0;
  private boolean showOptions = false;
  private final ImageDrawer imageHandler;

  public SquareDisplay(ApplicationContext context) {
    imageHandler = new ImageDrawer(context);
    this.context = context;
    try {
      imageHandler.loadImagesFromFolder("img/square/", imageMap);
    } catch (IOException e) {
      System.err.println("Failed to load images from folder: " + e.getMessage());
    }
  }


  public void drawGrid(Tile[][] array, Graphics2D graphics) {
    var screenInfo = context.getScreenInfo();
    var screenWidth = screenInfo.width();
    var screenHeight = screenInfo.height() - 150;
    var rows = array.length;
    var cols = array[0].length;

    var factor = Math.min(screenWidth / Math.max(1, cols), screenHeight / Math.max(1, rows));
    factor = Math.max(factor, 10); // Ensure minimum visibility
    imageHandler.drawImage("background", 0, 0, factor * cols, factor * rows, imageMap);
    for (var y = 0; y < rows; y++) {
      for (var x = 0; x < cols; x++) {
        var screenX = x * factor;
        var screenY = y * factor;
        if (array[y][x] != null) {
          imageHandler.drawImage(array[y][x].getAreaType().get(0).name(), screenX, screenY, factor, factor, imageMap);
          var offset = 0;
          for (var s : array[y][x].getAcceptedAnimals()) {
            imageHandler.drawImage(s.name(), screenX + 10 + offset, screenY + factor / 2 + offset, factor / 3,
                    factor / 3, imageMap);
            offset += 10;
          }
          if (array[y][x].getCurrentlyPlacedAnimal() != null) {
            imageHandler.drawImage(array[y][x].getCurrentlyPlacedAnimal().name(), screenX + 21, screenY + 21, factor / 2, factor / 2, imageMap);
          }
        } else {
          graphics.setColor(Color.BLACK);
          graphics.drawRect(screenX, screenY, factor, factor);
        }
        if (y == currentRow && x == currentCol) {
          graphics.setColor(new Color(255, 0, 0, 128)); // Translucent red
          graphics.fillRect(screenX, screenY, factor, factor);
        }
      }
    }
    displayTextBox(screenWidth, screenHeight, graphics);

  }

  public void drawIndividualCase(Tile[][] array, int x, int y, Graphics2D graphics) {
    var screenInfo = context.getScreenInfo();
    var screenWidth = screenInfo.width();
    var screenHeight = screenInfo.height() - 150;
    var rows = array.length;
    var cols = array[0].length;
    var factor = Math.min(screenWidth / Math.max(1, cols), screenHeight / Math.max(1, rows));
    factor = Math.max(factor, 10); // Ensure minimum visibility
    var screenX = x * factor;
    var screenY = y * factor;
    if (array[y][x] != null) {
      var offset = 0;
      imageHandler.drawImage(array[y][x].getAreaType().get(0).name(), screenX, screenY, factor, factor, imageMap);
      for (var s : array[y][x].getAcceptedAnimals()) {
        imageHandler.drawImage(s.name(), screenX + 10 + offset, screenY + factor / 2 + offset, factor / 3, factor / 3, imageMap);
        offset += 10;
      }
      if (array[y][x].getCurrentlyPlacedAnimal() != null) {
        imageHandler.drawImage(array[y][x].getCurrentlyPlacedAnimal().name(), screenX + 21, screenY + 21, factor / 2, factor / 2, imageMap);
      }
    } else {
      var originalImage = imageHandler.getImage("background", imageMap);
      var resizedImage = imageHandler.resizeImage(originalImage, factor * cols, factor * rows);
      imageHandler.drawImagePart(resizedImage, screenX, screenY, factor, factor, screenX, screenY, factor, factor);
      graphics.setColor(Color.BLACK);
      graphics.drawRect(screenX, screenY, factor, factor);
    }
    if (y == currentRow && x == currentCol) {
      graphics.setColor(new Color(255, 0, 0, 128)); // Translucent red
      graphics.fillRect(screenX, screenY, factor, factor);
    }

  }


  private void displayTextBox(int screenWidth, int screenHeight, Graphics2D graphics) {
    graphics.setColor(Color.BLACK);
    graphics.setStroke(new BasicStroke(4));
    graphics.drawRect(3, screenHeight, screenWidth - 7, 147);
    graphics.drawRect(3, screenHeight, screenWidth / 2, 147);
  }

  private void displayOptions(List<Tile> arrayOfOptions, List<AnimalType> animalOptions, Graphics2D graphics) {
    var screenInfo = context.getScreenInfo();
    var screenWidth = screenInfo.width(); // Reserve space for the options
    var screenHeight = screenInfo.height() - 150;
    var factor = 150 / 2;
    if (showOptions) {
      int optionX = 50; // Start drawing options in the reserved space
      int optionY = screenHeight + 10; // Start from the top
      for (var s : arrayOfOptions) {
        imageHandler.drawImage(s.getAreaType().get(0).name(), optionX, optionY, factor, factor, imageMap);
        int offset = 0;
        for (var v : s.getAcceptedAnimals()) {
          imageHandler.drawImage(v.name(), optionX + 10 + offset, optionY + factor / 2 + offset, factor / 3, factor / 3, imageMap);
          offset += 10;
        }
        optionX += factor + 13; // Move down for the next option
      }
      int optionXX = 50; // Start drawing options in the reserved space
      int optionYY = screenHeight + 10 + factor; // Start from the top
      for (var s : animalOptions) {
        imageHandler.drawImage(s.name(), optionXX, optionYY, factor - 20, factor - 20, imageMap);
        optionXX += factor + 10;
      }


    }
  }

  /**
   * Toggles the display of 4 random options.
   */
  public void toggleOptions(List<Tile> arrayOfOptions, List<AnimalType> animalOptions, Graphics2D graphics) {
    showOptions = true;
    displayOptions(arrayOfOptions, animalOptions, graphics);
    displayTextWithSize("choose : A B C D", Color.BLACK, 30, graphics);
  }

  public void displayTextWithSize(String text, Color color, int fontSize, Graphics2D graphics) {
    var screenInfo = context.getScreenInfo();
    var screenWidth = screenInfo.width(); // Reserve space for the options
    var screenHeight = screenInfo.height() - 150;
    graphics.setColor(Color.GREEN);
    graphics.fillRect(screenWidth / 2 + 4, screenHeight + 2, screenWidth / 2 - 10, 143);
    graphics.setColor(color);
    graphics.setFont(new java.awt.Font("Arial", Font.PLAIN, fontSize)); // Ensure using java.awt.Font
    graphics.drawString(text, screenWidth / 2 + 4, screenHeight + 27);

  }


  public void moveUp() {
    currentRow = Math.max(currentRow - 1, 0);
  }

  public void moveDown(Tile[][] array) {
    currentRow = Math.min(currentRow + 1, array.length - 1);
  }

  public void moveLeft() {
    currentCol = Math.max(currentCol - 1, 0);
  }

  public void moveRight(Tile[][] array) {
    currentCol = Math.min(currentCol + 1, array[0].length - 1);
  }

  public int getCurrentRow() {
    return currentRow;
  }

  public int getCurrentCol() {
    return currentCol;
  }


  public ApplicationContext context() {
    return context;
  }
}
