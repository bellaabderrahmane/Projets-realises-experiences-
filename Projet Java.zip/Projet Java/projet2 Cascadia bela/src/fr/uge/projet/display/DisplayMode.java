package fr.uge.projet.display;


/**
 * Enum representing the different display modes for the game.
 */
public enum DisplayMode {
  /**
   * Terminal display mode.
   */
  TERMINAL,

  /**
   * Square grid display mode.
   */
  SQUARE,

  /**
   * Hexagonal grid display mode.
   */
  HEXAGON;
}
