package fr.uge.projet.display.impl;

import java.util.List;
import java.util.Scanner;

import fr.uge.projet.display.GameDisplay;
import fr.uge.projet.engine.AnimalType;
import fr.uge.projet.engine.Player;
import fr.uge.projet.engine.Tile;

public class TerminalDisplay implements GameDisplay {

  // Draw a grid of tiles, including null tiles adjacent to non-null tiles
  public void drawBoard(Tile[][] board) {

    var minX = 3;

    // Process columns
    for (var y = 0; y < 7; y++) {
      var rowHasRelevantTile = false;
      for (var x = 0; x < 11; x++) {
        var tile = board[y][x];
        if (tile != null || hasAdjacentNonNullTile(board, y, x)) {
          rowHasRelevantTile = true;
          break; // No need to check further; this row is relevant
        }
      }

      // Skip the row if it doesn't have any relevant tiles
      if (!rowHasRelevantTile) {
        continue;
      }

      var topRow = new StringBuilder();
      var middleRow = new StringBuilder();
      var allowedAnimalsFirstRow = new StringBuilder();
      var allowedAnimalsSecondRow = new StringBuilder();
      var animalLineRow = new StringBuilder();
      var bottomRow = new StringBuilder();
      for (int x = 0; x < 11; x++) {
        var tile = board[y][x];
        if (tile != null || hasAdjacentNonNullTile(board, y, x)) {
          minX = Math.min(x, minX);
          //System.out.println(tile != null ? "full" : " E");
          topRow.append("+----------+");
          String terrainSymbol = tile != null ? tile.getAreaType().get(0).name() : " E";
          middleRow.append(formatLine(terrainSymbol));
          String allowedAnimalFirst = tile != null ? tile.getAcceptedAnimals().get(0).name() : " E";
          allowedAnimalsFirstRow.append(formatLine(allowedAnimalFirst));
          String allowedAnimalSecond = tile != null ? tile.getAcceptedAnimals().get(1).name() : " E";
          allowedAnimalsSecondRow.append(formatLine(allowedAnimalSecond));
          String animalSymbol = (tile != null && tile.getCurrentlyPlacedAnimal() != null)
                  ? tile.getCurrentlyPlacedAnimal().name()
                  : "XXX";
          animalLineRow.append(formatLine(animalSymbol));
          bottomRow.append("+----------+");
        } else if (x >= minX) {
          topRow.append("            ");
          middleRow.append("            ");
          allowedAnimalsFirstRow.append("            ");
          allowedAnimalsSecondRow.append("            ");
          animalLineRow.append("            ");
          bottomRow.append("            ");
        }

      }
      System.out.print(topRow.append("\n"));
      System.out.print(middleRow.append("\n"));
      System.out.print(allowedAnimalsFirstRow.append("\n"));
      System.out.print(allowedAnimalsSecondRow.append("\n"));
      System.out.print(animalLineRow.append("\n"));
      System.out.print(bottomRow.append("\n"));
    }

  }

  private StringBuilder formatLine(String content) {
    var filler = new StringBuilder();
    return filler.append("| ").append(content).repeat(" ", 12 - content.length() - 4).append(" |");
  }

  // Checks if a null tile is adjacent to a non-null tile
  private boolean hasAdjacentNonNullTile(Tile[][] board, int row, int col) {
    int[] rowOffsets = {-1, 1, 0, 0};
    int[] colOffsets = {0, 0, -1, 1};
    for (var i = 0; i < 4; i++) {
      var adjRow = row + rowOffsets[i];
      var adjCol = col + colOffsets[i];

      if (adjRow >= 0 && adjRow < board.length && adjCol >= 0 && adjCol < board[0].length) {
        if (board[adjRow][adjCol] != null) {
          return true;
        }
      }
    }
    return false;
  }

  public void displayTileAndAnimalChoices(List<Tile> tiles, List<AnimalType> animals) {
    for (var i = 0; i < tiles.size(); i++) {
      var tile = tiles.get(i);
      var animal = animals.get(i);
      System.out.println((i + 1) + "- Tile: Habitats " + tile.getAreaType() + ", Accepted Animals: " +
              tile.getAcceptedAnimals() + ", Animal: " + animal);
    }
  }


  public int getValidInteger(Scanner scanner, String prompt, java.util.function.IntPredicate validation) {
    var input = 0;
    while (true) {
      System.out.print(prompt);
      try {
        if (!scanner.hasNextLine()) {
          throw new IllegalStateException("No input available.");
        }
        input = Integer.parseInt(scanner.nextLine());
        if (validation.test(input)) {
          break;
        } else {
          System.out.println("Invalid input. Please try again within the respected range.");
        }
      } catch (NumberFormatException e) {
        System.out.println("Invalid input. Please enter a valid number.");
      }
    }
    return input;
  }

  public void placeAnimal(Player currentPlayer, AnimalType selectedAnimal, Scanner scanner, TerminalDisplay terminalDisplay) {
    var animalPlaced = false;

    while (!animalPlaced) {
      var animalRow = getValidInteger(scanner, "Enter row for the animal: ", n -> n >= 0 && n < 25);
      var animalCol = getValidInteger(scanner, "Enter column for the animal: ", n -> n >= 0 && n < 25);

      if (currentPlayer.placeAnimal(currentPlayer.getBoard(), animalRow, animalCol, selectedAnimal)) {
        animalPlaced = true;
        System.out.println("------------------------------{Animal placed successfully.}------------------------------");
      } else {
        terminalDisplay.drawBoard(currentPlayer.getBoard().getTilesTable());
        System.out.println("------------------------------{Invalid placement. Try again.}------------------------------");
      }
    }
  }


  public void placeTile(Player currentPlayer, Tile selectedTile, Scanner scanner, TerminalDisplay terminalDisplay, List<Tile> tiles, List<AnimalType> animals) {
    boolean tilePlaced = false;
    while (!tilePlaced) {
      int tileRow = terminalDisplay.getValidInteger(scanner, "Enter row for the tile: ", n -> n >= 0 && n < 25);
      int tileCol = terminalDisplay.getValidInteger(scanner, "Enter column for the tile: ", n -> n >= 0 && n < 25);

      if (currentPlayer.placeTile(selectedTile, tileRow, tileCol, 0)) {
        tilePlaced = true;
        System.out.println("------------------------------{Tile placed successfully.}------------------------------");
      } else {
        //clearTerminal();
        terminalDisplay.drawBoard(currentPlayer.getBoard().getTilesTable());
        terminalDisplay.displayTileAndAnimalChoices(tiles, animals);
        System.out.println("------------------------------{Invalid placement. Try again.}------------------------------");
      }
    }
    //clearTerminal();
    terminalDisplay.drawBoard(currentPlayer.getBoard().getTilesTable());
  }


}
