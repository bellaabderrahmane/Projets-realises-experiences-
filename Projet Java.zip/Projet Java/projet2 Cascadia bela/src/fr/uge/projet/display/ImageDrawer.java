package fr.uge.projet.display;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.imageio.ImageIO;

import com.github.forax.zen.Application;
import com.github.forax.zen.ApplicationContext;

/**
 * The ImageDrawer class deals with retrieving images from files and rendering
 * them on the screen.
 */
public class ImageDrawer {
    private final ApplicationContext context;
    private final Map<String, BufferedImage> imageMap = new HashMap<>(); // Store images by name

    public ImageDrawer(ApplicationContext context) {
        this.context = Objects.requireNonNull(context);
    }

    /**
     * Loads an image from a file and stores it in the map with a given name.
     *
     * @param name      The name to associate with the image.
     * @param filePath  The path to the image file.
     */
    public void loadImage(String name, String filePath,Map<String, BufferedImage> imageMap) {
        Objects.requireNonNull(name);
        Objects.requireNonNull(filePath);

        try (var input = Files.newInputStream(Path.of(filePath))) {
            var image = ImageIO.read(input);
            imageMap.put(name, image);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load image from " + filePath, e);
        }
    }

    /**
     * Loads all images from a specified folder and adds them to the image map.
     * The file name (without extension) is used as the image name.
     *
     * @param folderPath The path to the folder containing images.
     * @throws IOException if an I/O error occurs while accessing the folder.
     */
    public void loadImagesFromFolder(String folderPath,Map<String, BufferedImage> imageMap) throws IOException {
        Objects.requireNonNull(folderPath);

        var folder = Path.of(folderPath);
        if (!Files.isDirectory(folder)) {
            throw new IllegalArgumentException("The specified path is not a directory: " + folderPath);
        }

        try (var paths = Files.newDirectoryStream(folder, "*.png")) { // Change filter to include other formats if needed
            for (var path : paths) {
                var fileName = path.getFileName().toString();
                var imageName = fileName.substring(0, fileName.lastIndexOf('.')); // Remove extension
                loadImage(imageName, path.toString(),imageMap);
            }
        }
    }

    /**
     * Draws the image associated with the given name at the specified position
     * and size.
     *
     * @param name The name of the image to draw.
     * @param x    The x-coordinate on the screen.
     * @param y    The y-coordinate on the screen.
     * @param width The width of the image to draw.
     * @param height The height of the image to draw.
     */
    public void drawImage(String name, int x, int y, int width, int height,Map<String, BufferedImage> imageMap) {
        Objects.requireNonNull(name);

        var image = imageMap.get(name);
        if (image == null) {
            throw new IllegalArgumentException("No image found with name: " + name);
        }

        context.renderFrame(graphics -> {
            graphics.drawImage(image, x, y, width, height, null);
        });
    }

  	public void drawImagePart(BufferedImage image, int x, int y, int width, int height, int srcX, int srcY, int srcWidth,
  			int srcHeight) {
  	
  		if (image == null) {
  			throw new IllegalArgumentException("No image found with name: " );
  		}
  		context.renderFrame(graphics -> {
  			graphics.drawImage(image, x, y, x + width, y + height, // Destination rectangle
  					srcX, srcY, srcX + srcWidth, srcY + srcHeight, // Source rectangle
  					null);
  		});
  	}
  	
  	public BufferedImage resizeImage(BufferedImage originalImage, int width, int height) {
      Objects.requireNonNull(originalImage, "Original image cannot be null");
      var resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
      var graphics = resizedImage.createGraphics();
      graphics.drawImage(originalImage, 0, 0, width, height, null);
      graphics.dispose();
      return resizedImage;
  }
  	
  	
  	public BufferedImage getImage(String name,Map<String, BufferedImage> imageMap) {
      var image = imageMap.get(name);
      if (image == null) {
          throw new IllegalArgumentException("No image found with name: " + name);
      }
      return image;
  }
    
    
    public static void main(String[] args) {
      Application.run(Color.WHITE, context -> {
          var imageDrawer = new ImageDrawer(context);
          var imageMap = new HashMap<String, BufferedImage>(); // Store images by name

          // Load all images from a folder
          try {
              imageDrawer.loadImagesFromFolder("img/square/",imageMap);
          } catch (IOException e) {
              System.err.println("Failed to load images from folder: " + e.getMessage());
              return;
          }

          // Draw a specific image from the loaded set
          //imageDrawer.drawImage("example", 100, 100, 200, 200); // "example" matches a file named "example.png"
          for (var name : imageMap.keySet()) {
            System.out.println(name);
          }
          
      });
      
      
      
  }
}
