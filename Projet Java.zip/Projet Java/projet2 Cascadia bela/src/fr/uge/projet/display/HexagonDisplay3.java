package fr.uge.projet.display;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

import com.github.forax.zen.*;

import fr.uge.projet.engine.AnimalType;
import fr.uge.projet.engine.Tile;



public class HexagonDisplay3 {
	
	private final ApplicationContext context;
	private final Map<String, BufferedImage> imageMap = new HashMap<>(); // Store images by name
	private int currentRow = 1;
	private int currentCol = 1;
	private ImageDrawer imageHandler; // Stores the selected options
	
	
	private double apothem ;

	public HexagonDisplay3(ApplicationContext context) {
		imageHandler = new ImageDrawer(context);
		this.context = context;
		try {
			imageHandler.loadImagesFromFolder("img/hexagon/", imageMap);
		} catch (IOException e) {
			System.err.println("Failed to load images from folder: " + e.getMessage());
			return;
		}
	}
	

	
	
	
	public void drawHexagon( Tile[][] tile,double apothem,int x ,int y) {
		double side = (2 * apothem) / Math.sqrt(3);
		int cy = (int) (side + ((side * 3 * y) / 2)); // Adjust vertical position for staggered rows
        int offsetXXX = (y % 2 == 0) ? 0 : 1; // Apply horizontal offset for staggered rows
        int cx = (int) apothem * (x+offsetXXX) + (int) apothem;
        
        
	    double radius = side;
	    Polygon hexagon = new Polygon();
	    for (int i = 0; i < 6; i++) {
	        double angleRad = Math.toRadians(90 + (60 * i));
	        int vx = (int) Math.round(cx + radius * Math.cos(angleRad));
	        int vy = (int) Math.round(cy + radius * Math.sin(angleRad));
	        hexagon.addPoint(vx, vy);
	    }
	
	    context.renderFrame(graphics -> {
	        //graphics.setColor(Color.GREEN);
	        //graphics.fillPolygon(hexagon);
	    	  if(tile[y][x+offsetXXX] != null) {
	    	  	imageHandler.drawImage(tile[y][x+offsetXXX].getAreaType().get(0).name(), cx-(int)apothem, cy-(int)side, (int)apothem*2, (int)side*2, imageMap);
	    	  }
	        graphics.setColor(Color.BLACK);
	        graphics.drawPolygon(hexagon);
	        
	        //System.out.println("here x : "+(x+offsetXXX)+" y : "+y);
	        //System.out.println("highlight x :" + currentCol + " y " + currentRow);
	        if (y == currentRow && (x)== currentCol) {
	        	//System.out.println("highlight " + (x+offsetXXX) + " " + y);
	        	
						graphics.setColor(new Color(255, 0, 0, 128)); // Translucent red with 50% transparency
	
						graphics.fillPolygon(hexagon);
						graphics.drawPolygon(hexagon);
					}
	        
	    });
	}

	
	
	public void drawHexagonGrid(Tile[][] array) {
    ScreenInfo screenInfo = context.getScreenInfo();
    int rows = array.length;
    int cols = array[0].length;

    double maxVerticalSpace = (screenInfo.height()*Math.sqrt(3)-150) / (rows *2); // Account for staggered rows (height = 1.5x side length)
    double maxHorizontalSpace = screenInfo.width() / ((cols % 2 == 0) ? (cols / 2) : ((cols + 1) / 2)); // Account for hex width = sqrt(3) * side length
    // Apothem is based on the smaller dimension to ensure the grid fits the screen
    double apothem = Math.min(maxVerticalSpace, maxHorizontalSpace)/2;
    //imageHandler.drawImage("background", 0, 0, (int)(2*apothem * numberHexCol + apothem ), length, imageMap);
    context.renderFrame(graphics -> {
    	BufferedImage originalImage = imageHandler.getImage("background",imageMap);
      BufferedImage resizedImage = imageHandler.resizeImage(originalImage, screenInfo.height(), screenInfo.width());
      graphics.drawImage(resizedImage, 0, 0, screenInfo.width(), screenInfo.height(), null);    // Draw the hexagonal grid
    });
    
    for (int y = 0; y < rows; y++) {
        for (int x = 0 ; x < cols; x += 2) { 
        	
        	  	drawHexagon(array,apothem,x,y);
        	  
            
        }
    }
    
    
}





	public void moveUp() {
    currentRow = Math.max(currentRow - 1, 0);
    currentCol = Math.max(currentCol - 1, 0);
	}
	
	public void moveDown(Tile[][] array) {
	    currentRow = Math.min(currentRow + 1, array.length - 1);
	    currentCol = Math.max(currentCol - 1, 0);	
  }
	
	public void moveLeft() {
	    currentCol = Math.max(currentCol - 2, 0);
	}
	
	public void moveRight(Tile[][] array) {
	    currentCol = Math.min(currentCol + 2, array[0].length - 1);
	}
	
	public int getCurrentRow() {
	    return currentRow;
	}
	
	public int getCurrentCol() {
	    return currentCol;
	}
	
	public void setCurrentCol(int number) {
    currentCol = number;
}
	public void setCurrentRow(int number) {
    currentRow = number;
}

	
	 public static void main(String[] args) {
	    Application.run(Color.WHITE, context -> {
	        HexagonDisplay3 hexDisplay = new HexagonDisplay3(context);
	        // Retrieve screen info to draw a hexagon at the center
	        ScreenInfo screenInfo = context.getScreenInfo();
	        int centerX = screenInfo.width() / 2;
	        int centerY = screenInfo.height() / 2;

	        Tile[][] tiles = new Tile[10][30] ;
	        hexDisplay.drawHexagonGrid(tiles);
	        // Keep the application running until an event occurs
	        // (like pressing ESC or closing the window)
	        
	    });
	}

}
