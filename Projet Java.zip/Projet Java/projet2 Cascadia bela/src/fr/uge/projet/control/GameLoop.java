package fr.uge.projet.control;

import fr.uge.projet.engine.*;

import java.util.*;

/**
 * Abstract class that represents the core game loop, providing methods for handling tiles, animals, and player actions.
 */
public abstract class GameLoop {

  protected final List<Tile> drawTilesOptions;
  protected final List<AnimalType> drawAnimalOptions;
  protected final GameBag gameBag;

  /**
   * Constructs a GameLoop with the specified game bag.
   *
   * @param bag the game bag containing tiles and animals
   * @throws NullPointerException if the game bag is null
   */
  public GameLoop(GameBag bag) {
    this.gameBag = Objects.requireNonNull(bag, "Game bag cannot be null");
    this.drawTilesOptions = new ArrayList<>();
    this.drawAnimalOptions = new ArrayList<>();
  }

  /**
   * Starts the game loop.
   */
  public abstract void start();

  /**
   * Checks if a player can accept a specific animal on their board.
   *
   * @param currentPlayer the current player
   * @param selectedAnimal the animal to check
   * @return true if the player can accept the animal, false otherwise
   */
  protected boolean canAcceptAnimal(Player currentPlayer, AnimalType selectedAnimal) {
    for (var coord : currentPlayer.getBoard().getplayerTilesCoordinates()) {
      var targetTile = currentPlayer.getBoard().getTile(coord.y(), coord.x());
      if (targetTile.getAcceptedAnimals().contains(selectedAnimal) && targetTile.getCurrentlyPlacedAnimal() == null) {
        return true;
      }
    }
    return false;
  }

  /**
   * Returns a single animal to the game bag and reshuffles the animal bag.
   *
   * @param animal the animal to return
   */
  protected void returnAnimalToBag(AnimalType animal) {
    gameBag.addAnimal(animal);
    gameBag.shuffle(BagType.ANIMALS);
  }

  /**
   * Returns a list of animals to the game bag and reshuffles the animal bag.
   *
   * @param animals the list of animals to return
   */
  protected void returnAnimalsToBag(List<AnimalType> animals) {
    for (var animal : animals) {
      gameBag.addAnimal(animal);
    }
    gameBag.shuffle(BagType.ANIMALS);
  }

  /**
   * Counts the most frequent animal in a list.
   *
   * @param animals the list of animals
   * @return the count of the most frequent animal
   */
  protected int countMostFrequent(List<AnimalType> animals) {
    if (animals.isEmpty()) {
      return 0;
    }

    var frequencyMap = new HashMap<AnimalType, Integer>();
    for (var animal : animals) {
      frequencyMap.put(animal, frequencyMap.getOrDefault(animal, 0) + 1);
    }

    var maxCount = 0;
    for (var count : frequencyMap.values()) {
      if (count > maxCount) {
        maxCount = count;
      }
    }

    return maxCount;
  }

  /**
   * Checks if all animals in a list are the same.
   *
   * @param animals the list of animals
   * @return true if all animals are the same, false otherwise
   */
  protected boolean allSame(List<AnimalType> animals) {
    return animals.stream().distinct().count() == 1;
  }
}
