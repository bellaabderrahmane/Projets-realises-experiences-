package fr.uge.projet.control;

import fr.uge.projet.engine.*;

import java.util.*;

/**
 * Manages the game bag containing tiles and animals, providing methods to shuffle and draw tiles and animals.
 */
public class GameBag {

  private final List<Tile> tileSac;
  private final List<AnimalType> animalSac;

  /**
   * Constructs a GameBag with the specified number of players.
   *
   * @param playerCount the number of players, used to determine the number of tiles to generate
   */
  public GameBag(int playerCount) {
    this.tileSac = generateTileSac(playerCount * 21);
    this.animalSac = generateAnimalSac();
  }

  /**
   * Generates a list of tiles for the game bag.
   *
   * @param count the number of tiles to generate
   * @return a list of generated tiles
   */
  private List<Tile> generateTileSac(int count) {
    var tiles = new ArrayList<Tile>();
    var random = new Random();
    for (var i = 0; i < count; i++) {
      var habitats = pickValidCombination();
      var acceptedAnimals = new ArrayList<AnimalType>();
      acceptedAnimals.add(AnimalType.values()[random.nextInt(AnimalType.values().length)]);
      acceptedAnimals.add(AnimalType.values()[random.nextInt(AnimalType.values().length)]);
      tiles.add(new Tile(habitats, acceptedAnimals));
    }
    Collections.shuffle(tiles);
    return tiles;
  }

  /**
   * Generates a list of animals for the game bag.
   *
   * @return a list of generated animals
   */
  private List<AnimalType> generateAnimalSac() {
    var animals = new ArrayList<AnimalType>();
    for (var animal : AnimalType.values()) {
      for (int i = 0; i < 20; i++) {
        animals.add(animal);
      }
    }
    Collections.shuffle(animals);
    return animals;
  }

  /**
   * Removes and returns the first tile from the tile sac.
   *
   * @return the first tile
   */
  public Tile removeFirstTile() {
    return tileSac.removeFirst();
  }

  /**
   * Removes and returns the first animal from the animal sac.
   *
   * @return the first animal
   */
  public AnimalType removeFirstAnimal() {
    return animalSac.removeFirst();
  }

  /**
   * Shuffles either the animals or tiles in the game bag.
   *
   * @param bagType the type of bag to shuffle (animals or tiles)
   */
  public void shuffle(BagType bagType) {
    switch (bagType) {
      case ANIMALS -> Collections.shuffle(animalSac);
      case TILES -> Collections.shuffle(tileSac);
    }
  }

  /**
   * Adds all animals to the animal sac.
   *
   * @param animals the list of animals to add
   * @throws NullPointerException if the animals list is null
   */
  public void addAllAnimals(List<AnimalType> animals) {
    Objects.requireNonNull(animals, "Animals list cannot be null");

    for (AnimalType animal : animals) {
      addAnimal(animal);
    }
  }

  /**
   * Adds a single animal to the animal sac.
   *
   * @param animal the animal to add
   * @throws NullPointerException if the animal is null
   */
  public void addAnimal(AnimalType animal) {
    Objects.requireNonNull(animal, "Animal cannot be null");

    animalSac.add(animal);
  }

  /**
   * Picks a valid combination of two habitats for a tile.
   *
   * @return a list containing two random habitats
   */
  public List<AreaType> pickValidCombination() {
    var random = new Random();
    var habitats = new ArrayList<AreaType>(2);
    while (true) {
      habitats.clear();
      habitats.add(AreaType.values()[random.nextInt(AreaType.values().length)]);
      habitats.add(AreaType.values()[random.nextInt(AreaType.values().length)]);

      String candidate = habitats.get(0).name() + "_" + habitats.get(1).name();
      try {
        AreaFirstHalf firstHalf = AreaFirstHalf.valueOf(candidate);
        return habitats;
      } catch (IllegalArgumentException e) {
      }
    }

  }
}
