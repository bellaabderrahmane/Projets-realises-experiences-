package fr.uge.projet.control.impl;

import com.github.forax.zen.ApplicationContext;
import com.github.forax.zen.KeyboardEvent;
import com.github.forax.zen.ScreenInfo;
import fr.uge.projet.control.GameBag;
import fr.uge.projet.control.GameLoop;
import fr.uge.projet.control.ManagerHandler;
import fr.uge.projet.control.PlayerManager;
import fr.uge.projet.display.impl.HexagonDisplay;
import fr.uge.projet.engine.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * HexagonGameLoop handles the main game loop for the hexagonal board game.
 * It manages the game flow, player turns, tile placement, and animal movement.
 */
public class HexagonGameLoop extends GameLoop {

  private final ApplicationContext context;
  private final PlayerManager playerManager;
  private int currentPlayerIndex;
  private final List<PlayerData> playerDataList;
  private boolean isOptionsDrawn;

  /**
   * Constructs a new HexagonGameLoop.
   *
   * @param managerHandler the ManagerHandler to manage game state
   * @param display the display object for rendering the game
   */
  public HexagonGameLoop(ManagerHandler managerHandler, HexagonDisplay display) {
    super(new GameBag(managerHandler.gameConfiguration().playerCount() * 21));
    this.playerManager = Objects.requireNonNull(managerHandler).playerManager();
    this.context = Objects.requireNonNull(display).context();
    this.playerDataList = new ArrayList<>();
    this.currentPlayerIndex = 0;
    this.isOptionsDrawn = false;
  }

  /**
   * Initializes the players and their boards.
   *
   * @param display the display object for rendering the game
   */
  private void initializePlayers(HexagonDisplay display) {
    for (var i = 0; i < playerManager.playerCount(); i++) {
      var board = new Board(4, 10);
      for (var j = 1; j < 6; j += 2) {
        var startingTile = gameBag.removeFirstTile();
        board.placeTile(1, j, startingTile, 1);
      }
      var playerData = new PlayerData("Player " + (i + 1), board);
      playerDataList.add(playerData);
    }
    display.setCurrentCol(1);
    display.setCurrentRow(1);
  }

  /**
   * Calculates the apothem for the hexagon based on screen size and board dimensions.
   *
   * @param playerBoard the board to calculate dimensions for
   * @param screenInfo the screen information for rendering the game
   * @return the apothem of the hexagon
   */
  private double calculateApothem(Tile[][] playerBoard, ScreenInfo screenInfo) {
    var rows = playerBoard.length;
    var cols = playerBoard[0].length;
    var maxVerticalSpace = (screenInfo.height() * Math.sqrt(3) - 150) / (rows * 2);
    var maxHorizontalSpace = (double) screenInfo.width() / ((cols % 2 == 0) ? (cols / 2) : ((cols + 1) / 2));
    return Math.min(maxVerticalSpace, maxHorizontalSpace) / 2;
  }

  @Override
  public void start() {
    var display = new HexagonDisplay(context);
    initializePlayers(display);

    var currentPlayerData = playerDataList.get(currentPlayerIndex);
    var playerBoard = currentPlayerData.getBoard().getTilesTable();
    var screenInfo = context.getScreenInfo();
    var apothem = calculateApothem(playerBoard, screenInfo);

    while (true) {
      if (!isOptionsDrawn) {
        renderOptions(currentPlayerData, display, playerBoard);
        isOptionsDrawn = true;
      }

      var event = context.pollOrWaitEvent(100);
      if (event instanceof KeyboardEvent keyboardEvent && keyboardEvent.action() == KeyboardEvent.Action.KEY_PRESSED) {
        handleKeyPress(keyboardEvent, currentPlayerData, display, playerBoard, apothem);
      }
    }
  }

  /**
   * Renders the available options for the player.
   *
   * @param currentPlayerData the current player data
   * @param display the display object for rendering the game
   * @param playerBoard the current player's board
   */
  private void renderOptions(PlayerData currentPlayerData, HexagonDisplay display, Tile[][] playerBoard) {
    currentPlayerData.setSelectedTile(null);
    currentPlayerData.setSelectedAnimal(null);

    while (currentPlayerData.getDrawTilesOptions().size() < 4) {
      currentPlayerData.getDrawTilesOptions().add(gameBag.removeFirstTile());
    }
    while (currentPlayerData.getDrawAnimalOptions().size() < 4) {
      currentPlayerData.getDrawAnimalOptions().add(gameBag.removeFirstAnimal());
    }

    display.drawHexagonGrid(playerBoard);
    context.renderFrame(graphics -> {
      display.toggleOptions(currentPlayerData.getDrawTilesOptions(), currentPlayerData.getDrawAnimalOptions(), graphics);
    });
  }

  /**
   * Handles key press events during the game loop.
   *
   * @param keyboardEvent the keyboard event to handle
   * @param currentPlayerData the current player data
   * @param display the display object for rendering the game
   * @param playerBoard the current player's board
   * @param apothem the size of the hexagon
   */
  private void handleKeyPress(KeyboardEvent keyboardEvent, PlayerData currentPlayerData, HexagonDisplay display,
                              Tile[][] playerBoard, double apothem) {
    // Sélection de la tuile
    if (keyboardEvent.key() == KeyboardEvent.Key.A || keyboardEvent.key() == KeyboardEvent.Key.B ||
            keyboardEvent.key() == KeyboardEvent.Key.C || keyboardEvent.key() == KeyboardEvent.Key.D) {
      handleTileSelection(keyboardEvent, currentPlayerData);
    }

    if (currentPlayerData.getSelectedTile() != null) {
      context.renderFrame(graphics -> {
        display.displayTextWithSize("Now place your tile", Color.BLACK, 30, graphics);
      });
    }

    if (currentPlayerData.canPlaceAnimal()) {
      if (currentPlayerData.getSelectedAnimal() != null) {
        context.renderFrame(graphics -> {
          display.displayTextWithSize("Choose where to put the animal", Color.BLACK, 30, graphics);
        });
      } else {
        context.renderFrame(graphics -> {
          display.displayTextWithSize("No animal selected", Color.RED, 30, graphics);
        });
      }
    }

    if (currentPlayerData.canPlaceAnimal() && currentPlayerData.getSelectedAnimal() != null) {
      handleAnimalPlacement(keyboardEvent, currentPlayerData, display, apothem);
    }

    if (currentPlayerData.getSelectedTile() != null && currentPlayerData.getSelectedAnimal() != null) {
      handleTilePlacement(keyboardEvent, currentPlayerData, display, playerBoard, apothem);
    }
  }

  /**
   * Handles the tile selection based on the key pressed.
   *
   * @param keyboardEvent the keyboard event to handle
   * @param currentPlayerData the current player data
   */
  private void handleTileSelection(KeyboardEvent keyboardEvent, PlayerData currentPlayerData) {
    var index = switch (keyboardEvent.key()) {
      case A -> 0;
      case B -> 1;
      case C -> 2;
      case D -> 3;
      default -> -1;
    };
    if (index < currentPlayerData.getDrawTilesOptions().size()) {
      // Sélectionner la tuile et l'animal correspondant
      currentPlayerData.setSelectedTile(currentPlayerData.getDrawTilesOptions().remove(index));
      currentPlayerData.setSelectedAnimal(currentPlayerData.getDrawAnimalOptions().remove(index));
    }
  }


  /**
   * Handles the tile placement and animal placement based on the key pressed.
   *
   * @param keyboardEvent the keyboard event to handle
   * @param currentPlayerData the current player data
   * @param display the display object for rendering the game
   * @param playerBoard the current player's board
   * @param apothem the size of the hexagon
   */
  private void handleTilePlacement(KeyboardEvent keyboardEvent, PlayerData currentPlayerData, HexagonDisplay display,
                                   Tile[][] playerBoard, double apothem) {
    var oldPositionX = display.getCurrentCol();
    var oldPositionY = display.getCurrentRow();

    switch (keyboardEvent.key()) {
      case UP -> display.moveUp();
      case DOWN -> display.moveDown(playerBoard);
      case LEFT -> display.moveLeft();
      case RIGHT -> display.moveRight(playerBoard);
      case H -> {handleTileRotationAndPlacement(currentPlayerData, display, playerBoard, apothem);}
      case ESCAPE -> {
        return;
      }
    }
    display.updateHighlight(playerBoard, apothem, oldPositionX, oldPositionY);
  }

  private void handleAnimalPlacement(KeyboardEvent keyboardEvent, PlayerData currentPlayerData, HexagonDisplay display, double apothem) {
    var oldPositionX = display.getCurrentCol();
    var oldPositionY = display.getCurrentRow();
    var playerBoard = currentPlayerData.getBoard();

    switch (keyboardEvent.key()) {
      case UP -> display.moveUp();
      case DOWN -> display.moveDown(playerBoard.getTilesTable());
      case LEFT -> display.moveLeft();
      case RIGHT -> display.moveRight(playerBoard.getTilesTable());
      case H -> {
        if (TileValidation.isValidAnimalPlacement(currentPlayerData.getBoard().getTile(display.getCurrentRow(), display.getCurrentCol()), currentPlayerData.getSelectedAnimal())) {
          currentPlayerData.getBoard().placeAnimal(display.getCurrentRow(), display.getCurrentCol(), currentPlayerData.getSelectedAnimal());
          display.drawHexagon(playerBoard.getTilesTable(), apothem, display.getCurrentCol(), display.getCurrentRow());
          currentPlayerData.setCanPlaceAnimal(false);
          currentPlayerIndex = (currentPlayerIndex + 1) % playerManager.playerCount();
          isOptionsDrawn = false;
        }
      }
      case ESCAPE -> {
        return;
      }
    }
    display.updateHighlight(playerBoard.getTilesTable(), apothem, oldPositionX, oldPositionY);

  }

  /**
   * Handles the rotation and placement of the tile when the "H" key is pressed.
   *
   * @param currentPlayerData the current player data
   * @param display the display object for rendering the game
   * @param playerBoard the current player's board
   * @param apothem the size of the hexagon
   */
  private void handleTileRotationAndPlacement(PlayerData currentPlayerData, HexagonDisplay display,
                                              Tile[][] playerBoard, double apothem) {
    var currentRow = display.getCurrentRow();
    var currentCol = display.getCurrentCol();

    if (TileValidation.isValidTilePlacementHex(currentPlayerData.getBoard(), currentPlayerData.getSelectedTile(), currentRow, currentCol)) {
      currentPlayerData.getBoard().placeTileHex(currentRow, currentCol, currentPlayerData.getSelectedTile(), 0);
      display.drawHexagon(playerBoard, apothem, currentCol, currentRow);
      pivotInteraction(context, playerBoard, apothem, currentRow, currentCol, display);

      currentPlayerData.setSelectedTile(null);

      currentPlayerData.setCanPlaceAnimal(true);
      //currentPlayerIndex = (currentPlayerIndex + 1) % playerManager.playerCount();
      //isOptionsDrawn = false;
    }
  }

  /**
   * Handles the interaction for pivoting a tile on the board.
   *
   * @param context the application context for handling events
   * @param playerBoard the current player's board
   * @param apothem the size of the hexagon
   * @param currentRow the current row of the selected tile
   * @param currentCol the current column of the selected tile
   * @param display the display object for rendering the game
   */
  public void pivotInteraction(ApplicationContext context, Tile[][] playerBoard, double apothem, int currentRow, int currentCol, HexagonDisplay display) {
    var tile = playerBoard[currentRow][currentCol];
    if (tile == null) {
      System.out.println("No tile at the specified position to pivot.");
      return;
    }

    context.renderFrame(graphics -> {
      display.displayTextWithSize("You may pivot", Color.BLACK, 30, graphics);
    });

    while (true) {
      var event = context.pollOrWaitEvent(100);
      if (event instanceof KeyboardEvent keyboardEvent && keyboardEvent.action() == KeyboardEvent.Action.KEY_PRESSED) {
        switch (keyboardEvent.key()) {
          case RIGHT -> {
            var pivot = tile.getnumberOfPivots();
            pivot++;
            if (pivot > 5) pivot = 0;
            tile.setnumberOfPivots(pivot);
            display.drawHexagon(playerBoard, apothem, currentCol, currentRow);
          }
          case LEFT -> {
            var pivot = tile.getnumberOfPivots();
            pivot--;
            if (pivot < 0) pivot = 5;
            tile.setnumberOfPivots(pivot);
            display.drawHexagon(playerBoard, apothem, currentCol, currentRow);
          }
          case H -> {
            return;
          }
        }
      }
    }
  }
}
