package fr.uge.projet.control.impl;

import fr.uge.projet.control.GameBag;
import fr.uge.projet.control.GameLoop;
import fr.uge.projet.control.ManagerHandler;
import fr.uge.projet.display.impl.TerminalDisplay;
import fr.uge.projet.engine.AnimalType;

import java.util.Scanner;
/**
 * This class represents the game loop for a terminal-based game.
 * It handles the flow of the game, player turns, tile and animal placements, and user input.
 */
public class TerminalGameLoop extends GameLoop {

  private final TerminalDisplay terminalDisplay;
  private final ManagerHandler managerHandler;

  /**
   * Constructs a new game loop for a terminal-based game.
   *
   * @param managerHandler the manager handler to manage the game configuration
   * @param display the terminal display instance to render the game
   */
  public TerminalGameLoop(ManagerHandler managerHandler, TerminalDisplay display) {
    super(new GameBag(managerHandler.gameConfiguration().playerCount() * 21));
    this.managerHandler = managerHandler;
    this.terminalDisplay = display;

    managerHandler.playerManager().initializePlayers(gameBag);
  }

  /**
   * Starts the game loop. It continuously handles player input, updates the game state,
   * and renders the game in the terminal.
   */
  @Override
  public void start() {
    var playerManager = managerHandler.playerManager();
    playerManager.initializePlayers(gameBag);

    var scanner = new Scanner(System.in);
    var currentPlayerIndex = 0;

    while (true) {
      var currentPlayer = playerManager.player(currentPlayerIndex);
      System.out.println("\n------------------------------{ Player " + (currentPlayerIndex + 1) + "'s turn }------------------------------");

      terminalDisplay.drawBoard(currentPlayer.getBoard().getTilesTable());
      manageDrawOptions();

      handleAnimalRerolls(terminalDisplay, scanner);

      terminalDisplay.displayTileAndAnimalChoices(drawTilesOptions, drawAnimalOptions);

      var choice = terminalDisplay.getValidInteger(scanner, "Your choice: ", n -> n >= 1 && n <= 4) - 1;
      var selectedTile = drawTilesOptions.get(choice);
      var selectedAnimal = drawAnimalOptions.get(choice);

      terminalDisplay.placeTile(currentPlayer, selectedTile, scanner, terminalDisplay, drawTilesOptions, drawAnimalOptions);
      System.out.println("------------------------------{your animal : " + selectedAnimal.name() + "}------------------------------");

      if (!canAcceptAnimal(currentPlayer, selectedAnimal)) {
        System.out.println("------------------------------{The chosen tile cannot accept this animal. Returning it to the SAC.}------------------------------");
        returnAnimalToBag(selectedAnimal);
        continue;
      }

      terminalDisplay.placeAnimal(currentPlayer, selectedAnimal, scanner, terminalDisplay);

      drawTilesOptions.remove(choice);
      drawAnimalOptions.remove(choice);

      currentPlayerIndex = (currentPlayerIndex + 1) % playerManager.playerCount();
    }
  }

  /**
   * Manages the drawing of tile and animal options for the current player.
   */
  private void manageDrawOptions() {
    while (drawTilesOptions.size() < 4) {
      drawTilesOptions.add(gameBag.removeFirstTile());
    }
    while (drawAnimalOptions.size() < 4) {
      drawAnimalOptions.add(gameBag.removeFirstAnimal());
    }
  }

  /**
   * Handles rerolling of animal options if all animals are the same or if three animals are the same.
   *
   * @param terminalDisplay the terminal display to render messages
   * @param scanner the scanner to read user input
   */
  private void handleAnimalRerolls(TerminalDisplay terminalDisplay, Scanner scanner) {
    while (allSame(drawAnimalOptions)) {
      System.out.println("------------------------------{All animals are the same, reshuffling...}------------------------------");
      returnAnimalsToBag(drawAnimalOptions);
      drawAnimalOptions.clear();
      manageDrawOptions();
    }

    if (countMostFrequent(drawAnimalOptions) == 3) {
      System.out.println("------------------------------{Three animals are the same: }------------------------------");
      terminalDisplay.displayTileAndAnimalChoices(drawTilesOptions, drawAnimalOptions);
      System.out.print("------------------------------{Would you like to reroll? (y/n): ");
      var choice = scanner.nextLine();
      if (choice.equalsIgnoreCase("y")) {
        returnAnimalsToBag(drawAnimalOptions);
        drawAnimalOptions.clear();
        manageDrawOptions();
      }
    }
  }
}
