package fr.uge.projet.control;

import java.awt.Color;
import java.util.Scanner;
import java.util.Objects;

import com.github.forax.zen.Application;
import fr.uge.projet.control.impl.HexagonGameLoop;
import fr.uge.projet.control.impl.SquareGameLoop;
import fr.uge.projet.control.impl.TerminalGameLoop;
import fr.uge.projet.display.DisplayMode;
import fr.uge.projet.display.impl.HexagonDisplay;
import fr.uge.projet.display.impl.SquareDisplay;
import fr.uge.projet.display.impl.TerminalDisplay;

/**
 * Main class for the Cascadia game, responsible for initializing the game configuration
 * and starting the game loop based on the selected display mode.
 */
public class Cascadia {

	private static final Scanner scanner = new Scanner(System.in); // Global scanner to read user inputs

	/**
	 * The entry point of the game application.
	 * Initializes the game configuration and starts the game.
	 *
	 * @param args command-line arguments (not used)
	 */
	public static void main(String[] args) {
		var gameConfig = initializeGameConfiguration();
		startGame(gameConfig, gameConfig.displayMode());
	}

	/**
	 * Initializes the game configuration by prompting the user for the number of players
	 * and the display mode.
	 *
	 * @return the initialized game configuration
	 */
	private static GameConfiguration initializeGameConfiguration() {
		var playerCount = getValidPlayerCount();
		var displayMode = getValidDisplayMode();
		return new GameConfiguration(playerCount, displayMode);
	}

	/**
	 * Prompts the user to input a valid player count.
	 * Ensures the input is a positive integer.
	 *
	 * @return the number of players
	 */
	private static int getValidPlayerCount() {
		System.out.print("Input number of players: ");
		while (true) {
			try {
				var count = Integer.parseInt(scanner.nextLine().trim());
				if (count > 0) {
					return count;
				}
				System.out.print("Please enter a positive number: ");
			} catch (NumberFormatException e) {
				System.out.print("Please enter a valid number: ");
			}
		}
	}

	/**
	 * Prompts the user to select a display mode for the game.
	 * Ensures the input is one of the valid options: 1 (Terminal), 2 (Square Graphic), 3 (Hexagon Graphic).
	 *
	 * @return the selected display mode
	 */
	private static DisplayMode getValidDisplayMode() {
		System.out.println("Select display mode:");
		System.out.println("1. Terminal");
		System.out.println("2. Square Graphic");
		System.out.println("3. Hexagon Graphic");

		while (true) {
			try {
				var mode = Integer.parseInt(scanner.nextLine().trim());
				return switch (mode) {
					case 1 -> DisplayMode.TERMINAL;
					case 2 -> DisplayMode.SQUARE;
					case 3 -> DisplayMode.HEXAGON;
					default -> {
						System.out.print("Please enter 1, 2, or 3: ");
						yield null;
					}
				};
			} catch (NumberFormatException e) {
				System.out.print("Please enter a valid number: ");
			}
		}
	}

	/**
	 * Starts the game based on the provided configuration and display mode.
	 *
	 * @param gameConfiguration the game configuration containing player count and display mode
	 * @param displayMode the selected display mode
	 */
	private static void startGame(GameConfiguration gameConfiguration, DisplayMode displayMode) {
		Objects.requireNonNull(gameConfiguration, "Game configuration cannot be null");
		if (displayMode == null) {
			System.out.println("Display mode is invalid. Exiting the game.");
			return;
		}
		switch (displayMode) {
			case TERMINAL -> new TerminalGameLoop(new ManagerHandler(gameConfiguration), new TerminalDisplay()).start();
			case SQUARE -> Application.run(Color.WHITE, context ->
							new SquareGameLoop(new ManagerHandler(gameConfiguration), new SquareDisplay(context)).start());
			case HEXAGON -> Application.run(Color.WHITE, context ->
							new HexagonGameLoop(new ManagerHandler(gameConfiguration), new HexagonDisplay(context)).start());
		}
	}
}
