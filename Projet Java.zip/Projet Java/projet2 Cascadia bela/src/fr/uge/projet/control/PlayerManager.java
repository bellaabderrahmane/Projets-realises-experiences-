package fr.uge.projet.control;

import fr.uge.projet.engine.Board;
import fr.uge.projet.engine.Player;

import java.util.Objects;

/**
 * Manages the players in the game, including initializing players and managing their boards.
 */
public class PlayerManager {

  private final Player[] playerTable;
  private final int playerCount;

  /**
   * Constructs a PlayerManager with the specified number of players.
   *
   * @param playerCount the number of players in the game
   * @throws IllegalArgumentException if playerCount is less than or equal to 0
   */
  public PlayerManager(int playerCount) {
    if (playerCount <= 0) {
      throw new IllegalArgumentException("Player count must be positive");
    }
    this.playerCount = playerCount;
    this.playerTable = new Player[playerCount];
  }

  /**
   * Initializes the players by creating a new board for each and placing starting tiles on it.
   *
   * @param gameBag the game bag from which tiles are drawn for initialization
   */
  public void initializePlayers(GameBag gameBag) {
    Objects.requireNonNull(gameBag, "Game bag cannot be null");
    for (var i = 0; i < playerCount; i++) {
      var board = new Board(7, 11);
      for (var j = 0; j < 3; j++) {
        var startingTile = gameBag.removeFirstTile();
        board.placeTile(3, 6 + j, startingTile, 1);
      }
      var player = new Player("Player " + (i + 1), board);
      playerTable[i] = player;
    }
  }

  /**
   * Sets the player at the specified index in the player table.
   *
   * @param index the index at which to set the player
   * @param player the player to be set
   */
  public void setPlayer(int index, Player player) {
    Objects.requireNonNull(player, "Player cannot be null");
    playerTable[index] = player;
  }

  /**
   * Gets the player at the specified index from the player table.
   *
   * @param index the index of the player to retrieve
   * @return the player at the specified index
   */
  public Player player(int index) {
    if (index < 0 || index >= playerCount) {
      throw new IndexOutOfBoundsException("Invalid player index");
    }
    return playerTable[index];
  }

  /**
   * Gets the total number of players.
   *
   * @return the number of players
   */
  public int playerCount() {
    return playerCount;
  }
}
