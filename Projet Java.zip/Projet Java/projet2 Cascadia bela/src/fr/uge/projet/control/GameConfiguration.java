package fr.uge.projet.control;

import fr.uge.projet.display.DisplayMode;
import java.util.Objects;

/**
 * Game configuration record containing the player count and the display mode.
 * Ensures that the player count is positive and the display mode is not null.
 */
public record GameConfiguration(
        int playerCount,
        DisplayMode displayMode
) {
  /**
   * Constructor for the GameConfiguration record.
   * Ensures that playerCount is positive and displayMode is not null.
   *
   * @param playerCount the number of players
   * @param displayMode the display mode for the game
   * @throws IllegalArgumentException if playerCount is less than or equal to 0 or if displayMode is null
   */
  public GameConfiguration {
    if (playerCount <= 0) {
      throw new IllegalArgumentException("Player count must be positive");
    }
    Objects.requireNonNull(displayMode, "Display mode cannot be null");
  }
}
