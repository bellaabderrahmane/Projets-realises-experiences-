package fr.uge.projet.control;

import java.util.Objects;

/**
 * Manages the game configuration and player management during the game.
 */
public class ManagerHandler {

  private final PlayerManager playerManager;
  private final GameConfiguration gameConfiguration;

  /**
   * Constructs a ManagerHandler with the specified game configuration.
   *
   * @param gameConfiguration the game configuration containing the number of players and display mode
   * @throws NullPointerException if gameConfiguration is null
   */
  public ManagerHandler(GameConfiguration gameConfiguration) {
    this.gameConfiguration = Objects.requireNonNull(gameConfiguration, "Game configuration cannot be null");
    this.playerManager = new PlayerManager(gameConfiguration.playerCount());
  }

  /**
   * Gets the PlayerManager associated with this ManagerHandler.
   *
   * @return the PlayerManager
   */
  public PlayerManager playerManager() {
    return playerManager;
  }

  /**
   * Gets the GameConfiguration associated with this ManagerHandler.
   *
   * @return the GameConfiguration
   */
  public GameConfiguration gameConfiguration() {
    return gameConfiguration;
  }
}
