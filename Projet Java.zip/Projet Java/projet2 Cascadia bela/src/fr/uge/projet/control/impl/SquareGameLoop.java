package fr.uge.projet.control.impl;

import com.github.forax.zen.ApplicationContext;
import com.github.forax.zen.KeyboardEvent;
import fr.uge.projet.control.GameBag;
import fr.uge.projet.control.GameLoop;
import fr.uge.projet.control.ManagerHandler;
import fr.uge.projet.control.PlayerManager;
import fr.uge.projet.display.impl.SquareDisplay;
import fr.uge.projet.engine.*;

import java.awt.*;
import java.util.Objects;

/**
 * This class represents the game loop for a square-based game.
 * It handles game flow, player turns, tile and animal placements, and user input.
 */
public class SquareGameLoop extends GameLoop {
  private final SquareDisplay display;
  private final ApplicationContext context;
  private final PlayerManager playerManager;
  private boolean hasMadeAnOption;
  private boolean canPlaceATile;
  private boolean canPlaceAnAnimal;
  private int currentPlayerIndex;
  private boolean passToAnotherPlayer;
  private PlayerData currentPlayerData;
  private boolean optionsDrawn;

  /**
   * Constructs a new game loop for a square-based game.
   *
   * @param managerHandler the manager handler to manage the game configuration and player manager
   * @param display the display instance to render the game
   */
  public SquareGameLoop(ManagerHandler managerHandler, SquareDisplay display) {
    super(new GameBag(managerHandler.gameConfiguration().playerCount() * 21));
    this.playerManager = managerHandler.playerManager();
    this.display = display;
    this.context = display.context();
    this.currentPlayerIndex = 0;
    this.passToAnotherPlayer = true;
    this.optionsDrawn = false;  // Initialisation du flag à false

    playerManager.initializePlayers(gameBag);
  }

  /**
   * Starts the game loop. It continuously handles player input, updates the game state,
   * and renders the game.
   */
  @Override
  public void start() {
    while (true) {
      context.renderFrame(graphics -> {
        if (passToAnotherPlayer) {
          setupForNextPlayer(graphics);
        }

        if (currentPlayerData != null && !optionsDrawn) {  // Dessiner les options seulement une fois
          manageDrawOptions(graphics);
        }

        var event = context.pollOrWaitEvent(100);
        if (event instanceof KeyboardEvent keyboardEvent && keyboardEvent.action() == KeyboardEvent.Action.KEY_PRESSED) {
          handleKeyboardInput(keyboardEvent, graphics);
        }
      });
    }
  }

  /**
   * Manages the drawing of tile and animal options for the current player.
   *
   * @param graphics the graphics context to draw on the screen
   * @throws IllegalStateException if current player data is not initialized
   */
  private void manageDrawOptions(Graphics2D graphics) {
    Objects.requireNonNull(currentPlayerData, "Current player data is not initialized!");

    var drawTilesOptions = currentPlayerData.getDrawTilesOptions();
    var drawAnimalOptions = currentPlayerData.getDrawAnimalOptions();

    while (drawTilesOptions.size() < 4) {
      drawTilesOptions.add(gameBag.removeFirstTile());
    }
    while (drawAnimalOptions.size() < 4) {
      drawAnimalOptions.add(gameBag.removeFirstAnimal());
    }

    display.toggleOptions(drawTilesOptions, drawAnimalOptions, graphics);

    optionsDrawn = true;  // Mark the options as drawn
  }

  /**
   * Sets up the game for the next player by initializing their board and resetting flags.
   *
   * @param graphics the graphics context to draw on the screen
   * @throws IllegalStateException if current player data is not found
   */
  private void setupForNextPlayer(Graphics2D graphics) {
    currentPlayerData = playerManager.player(currentPlayerIndex).getData();
    Objects.requireNonNull(currentPlayerData, "Failed to retrieve player data for player at index " + currentPlayerIndex);

    display.drawGrid(currentPlayerData.getBoard().getTilesTable(), graphics);
    optionsDrawn = false;  // Reset flag at the start of the turn
    passToAnotherPlayer = false;
    hasMadeAnOption = false;
    canPlaceATile = false;
    canPlaceAnAnimal = false;
  }

  /**
   * Handles keyboard input for tile and animal placement, as well as navigation.
   *
   * @param keyboardEvent the keyboard event triggered by user input
   * @param graphics the graphics context to draw on the screen
   */
  private void handleKeyboardInput(KeyboardEvent keyboardEvent, Graphics2D graphics) {
    if (!hasMadeAnOption) {
      var index = switch (keyboardEvent.key()) {
        case A -> 0;
        case B -> 1;
        case C -> 2;
        case D -> 3;
        default -> -1;
      };

      if (index >= 0 && index < currentPlayerData.getDrawTilesOptions().size()) {
        currentPlayerData.setSelectedTile(currentPlayerData.getDrawTilesOptions().remove(index));
        currentPlayerData.setSelectedAnimal(currentPlayerData.getDrawAnimalOptions().remove(index));
        hasMadeAnOption = true;
        canPlaceATile = true;
      }
    }

    if (canPlaceATile) {
      display.displayTextWithSize("Now place your tile", Color.BLACK, 30, graphics);
    }

    if (canPlaceAnAnimal) {
      if (canAcceptAnimal(currentPlayerData.getSelectedAnimal())) {
        display.displayTextWithSize("Choose where to put the animal", Color.BLACK, 30, graphics);
      } else {
        display.displayTextWithSize("Animal cannot be placed", Color.BLACK, 30, graphics);
        passToAnotherPlayer = true;
        currentPlayerIndex = (currentPlayerIndex + 1) % playerManager.playerCount();
        hasMadeAnOption = false;
      }
    }

    if (hasMadeAnOption) {
      int oldPositionX = display.getCurrentCol();
      int oldPositionY = display.getCurrentRow();
      handleTilePlacement(keyboardEvent, oldPositionX, oldPositionY, graphics);
    }
  }

  /**
   * Handles the placement of tiles on the board based on user input.
   *
   * @param keyboardEvent the keyboard event triggered by user input
   * @param oldPositionX the old column position before moving
   * @param oldPositionY the old row position before moving
   * @param graphics the graphics context to draw on the screen
   */
  private void handleTilePlacement(KeyboardEvent keyboardEvent, int oldPositionX, int oldPositionY, Graphics2D graphics) {
    switch (keyboardEvent.key()) {
      case UP -> display.moveUp();
      case DOWN -> display.moveDown(currentPlayerData.getBoard().getTilesTable());
      case LEFT -> display.moveLeft();
      case RIGHT -> display.moveRight(currentPlayerData.getBoard().getTilesTable());
      case H -> {
        var currentRow = display.getCurrentRow();
        var currentCol = display.getCurrentCol();
        if (canPlaceAnAnimal) {
          handleAnimalPlacement(currentRow, currentCol);
        }
        if (canPlaceATile) {
          handleTilePlacementLogic(currentRow, currentCol);
        }
      }
      case ESCAPE -> System.exit(0); // Exit the game
    }
    display.drawIndividualCase(currentPlayerData.getBoard().getTilesTable(), oldPositionX, oldPositionY, graphics);
    display.drawIndividualCase(currentPlayerData.getBoard().getTilesTable(), display.getCurrentCol(), display.getCurrentRow(), graphics);
  }

  /**
   * Handles the placement of an animal on the board.
   *
   * @param currentRow the current row of the board
   * @param currentCol the current column of the board
   */
  private void handleAnimalPlacement(int currentRow, int currentCol) {
    if (TileValidation.isValidAnimalPlacement(currentPlayerData.getBoard().getTile(currentRow, currentCol), currentPlayerData.getSelectedAnimal())) {
      currentPlayerData.getBoard().placeAnimal(currentRow, currentCol, currentPlayerData.getSelectedAnimal());
      passToAnotherPlayer = true;
      currentPlayerIndex = (currentPlayerIndex + 1) % playerManager.playerCount();
      hasMadeAnOption = false;
    }
  }

  /**
   * Handles the logic for placing a tile on the board.
   *
   * @param currentRow the current row of the board
   * @param currentCol the current column of the board
   */
  private void handleTilePlacementLogic(int currentRow, int currentCol) {
    if (TileValidation.isValidTilePlacement(currentPlayerData.getBoard(), currentPlayerData.getSelectedTile(), currentRow, currentCol)) {
      currentPlayerData.getBoard().placeTile(currentRow, currentCol, currentPlayerData.getSelectedTile(), 0);
      canPlaceATile = false;
      canPlaceAnAnimal = true;
    }
  }

  /**
   * Checks if the selected animal can be placed.
   *
   * @param selectedAnimal the animal selected by the player
   * @return true if the animal can be placed, false otherwise
   */
  private boolean canAcceptAnimal(AnimalType selectedAnimal) {
    return selectedAnimal != null;
  }
}
