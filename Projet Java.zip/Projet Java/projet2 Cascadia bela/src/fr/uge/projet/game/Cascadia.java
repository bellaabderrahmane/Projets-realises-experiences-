package fr.uge.projet.game;


public class Cascadia {
    public static void main(String[] args) { 
      
    }
}