package fr.uge.projet.engine;

import fr.uge.projet.engine.AnimalType;
import fr.uge.projet.engine.AreaType;

import java.util.List;
import java.util.Objects;

/**
 * Tile class represents a tile in the game board.
 * It contains the types of areas it belongs to, the animals that can be placed on it,
 * the current animal placed on it, and the number of pivots associated with it.
 */
public class Tile {
	private final List<AreaType> type;
	private final List<AnimalType> acceptedAnimals;
	private AnimalType placedAnimal;
	private int numberOfPivots;

	/**
	 * Constructs a new Tile with the specified area types and accepted animals.
	 *
	 * @param type             the list of AreaType this tile belongs to
	 * @param acceptedAnimals  the list of AnimalType that can be placed on this tile
	 */
	public Tile(List<AreaType> type, List<AnimalType> acceptedAnimals) {
		this.type = Objects.requireNonNull(type, "AreaType cannot be null");
		this.acceptedAnimals = Objects.requireNonNull(acceptedAnimals, "Accepted animals list cannot be null");
		this.placedAnimal = null;
		this.numberOfPivots = 0;
	}

	/**
	 * Gets the list of area types this tile belongs to.
	 *
	 * @return a list of AreaType
	 */
	public List<AreaType> getAreaType() {
		return type;
	}

	/**
	 * Gets the list of animals that can be placed on this tile.
	 *
	 * @return a list of AnimalType
	 */
	public List<AnimalType> getAcceptedAnimals() {
		return acceptedAnimals;
	}

	/**
	 * Gets the currently placed animal on this tile.
	 *
	 * @return the currently placed AnimalType, or null if no animal is placed
	 */
	public AnimalType getCurrentlyPlacedAnimal() {
		return placedAnimal;
	}

	/**
	 * Gets the number of pivots associated with this tile.
	 *
	 * @return the number of pivots
	 */
	public int getnumberOfPivots() {
		return numberOfPivots;
	}

	/**
	 * Sets the number of pivots associated with this tile.
	 *
	 * @param number the number of pivots to set
	 */
	public void setnumberOfPivots(int number) {
		numberOfPivots = number;
	}

	/**
	 * Attempts to place an animal on this tile.
	 *
	 * @param animal the AnimalType to place on the tile
	 * @return true if the animal was placed successfully, false otherwise
	 */
	public boolean setPlacedAnimal(AnimalType animal) {
		Objects.requireNonNull(animal, "Animal cannot be null");
		if (acceptedAnimals.contains(animal)) {
			this.placedAnimal = animal;
			return true;
		}
		return false;
	}

	/**
	 * Returns a string representation of the Tile object.
	 *
	 * @return a string containing the Tile's details
	 */
	@Override
	public String toString() {
		return "Tile{" + "type=" + type + ", acceptedAnimals=" + acceptedAnimals + ", placedAnimal="
						+ (placedAnimal != null ? placedAnimal : "None") + '}';
	}
}