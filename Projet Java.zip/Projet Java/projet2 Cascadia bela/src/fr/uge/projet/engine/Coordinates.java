package fr.uge.projet.engine;

/**
 * Coordinates class represents the position of a tile on the board.
 * It contains the row (y) and column (x) coordinates.
 */
public record Coordinates(int y ,int x) {

}
