package fr.uge.projet.engine;

import java.util.ArrayList;
import java.util.List;

public class Board {
  private final Tile[][] tiles; // 2D array to represent the game board
  private final int rows;
  private final int cols;
  private final List<Coordinates> playerTilesCoordinates;

  /**
   * Constructs a new Board with the specified dimensions.
   *
   * @param rows the number of rows in the board
   * @param cols the number of columns in the board
   */
  public Board(int rows, int cols) {
    this.rows = rows;
    this.cols = cols;
    this.tiles = new Tile[rows][cols];
    this.playerTilesCoordinates = new ArrayList<>();
  }

  /**
   * Places a tile at the specified position on the board.
   *
   * @param row           the row where the tile should be placed
   * @param col           the column where the tile should be placed
   * @param tile          the tile to be placed
   * @param atInitialisation flag indicating whether the placement is during initialization
   * @return true if the tile was placed successfully, false otherwise
   */
  public boolean placeTile(int row, int col, Tile tile, int atInitialisation) {
    if (TileValidation.isValidTilePlacement(this, tile, row, col) || atInitialisation == 1) {
      tiles[row][col] = tile;
      playerTilesCoordinates.add(new Coordinates(row, col));
      return true;
    }
    return false;
  }

  /**
   * Places a tile at the specified position on the board for hexagonal placement.
   *
   * @param row           the row where the tile should be placed
   * @param col           the column where the tile should be placed
   * @param tile          the tile to be placed
   * @param atInitialisation flag indicating whether the placement is during initialization
   * @return true if the tile was placed successfully, false otherwise
   */
  public boolean placeTileHex(int row, int col, Tile tile, int atInitialisation) {
    if (TileValidation.isValidTilePlacementHex(this, tile, row, col) || atInitialisation == 1) {
      tiles[row][col] = tile;
      playerTilesCoordinates.add(new Coordinates(row, col));
      return true;
    }
    return false;
  }

  /**
   * Places an animal on a tile at the specified position.
   *
   * @param row     the row where the animal should be placed
   * @param col     the column where the animal should be placed
   * @param animal  the animal to be placed
   * @return true if the animal was placed successfully, false otherwise
   */
  public boolean placeAnimal(int row, int col, AnimalType animal) {
    if (TileValidation.isValidAnimalPlacement(tiles[row][col], animal)) {
      tiles[row][col].setPlacedAnimal(animal);
      return true;
    }
    return false;
  }

  /**
   * Retrieves the coordinates of all placed tiles by the player.
   *
   * @return a list of coordinates where tiles have been placed
   */
  public List<Coordinates> getplayerTilesCoordinates() {
    return playerTilesCoordinates;
  }

  /**
   * Retrieves the tile at a specific position on the board.
   *
   * @param row the row of the tile
   * @param col the column of the tile
   * @return the tile at the specified position, or null if the position is invalid
   */
  public Tile getTile(int row, int col) {
    if (isValidPosition(row, col)) {
      return tiles[row][col];
    }
    return null;
  }

  /**
   * Retrieves the entire board as a 2D array of tiles.
   *
   * @return a 2D array representing the board's tiles
   */
  public Tile[][] getTilesTable() {
    return tiles;
  }

  /**
   * Checks if a given position is valid on the board.
   *
   * @param row the row to check
   * @param col the column to check
   * @return true if the position is valid, false otherwise
   */
  private boolean isValidPosition(int row, int col) {
    return row >= 0 && row < rows && col >= 0 && col < cols;
  }

  /**
   * Retrieves the number of rows in the board.
   *
   * @return the number of rows
   */
  public int getRows() {
    return rows;
  }

  /**
   * Retrieves the number of columns in the board.
   *
   * @return the number of columns
   */
  public int getCols() {
    return cols;
  }
}