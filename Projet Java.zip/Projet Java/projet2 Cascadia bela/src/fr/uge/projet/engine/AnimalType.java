package fr.uge.projet.engine;

/**
 * Enum representing different types of animals in the game.
 */
public enum AnimalType {
	BEAR, DEER, SALMON, FOX, EAGLE
}
