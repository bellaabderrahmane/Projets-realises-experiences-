package fr.uge.projet.engine;

/**
 * Enum representing the types of bags used in the game.
 * These bags contain either animals or tiles.
 */
public enum BagType {
  ANIMALS,
  TILES
}
