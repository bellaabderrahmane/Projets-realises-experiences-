package fr.uge.projet.engine;

/**
 * Enum representing the type of game variant.
 */
public enum VariantType {
    FAMILY,
    INTERMEDIATE
}