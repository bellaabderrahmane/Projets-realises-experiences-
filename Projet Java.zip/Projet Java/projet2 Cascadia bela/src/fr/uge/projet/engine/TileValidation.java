package fr.uge.projet.engine;

import java.util.Objects;

/**
 * TileValidation class contains methods for validating tile placements
 * and animal placements on the board.
 */
public class TileValidation {

    /**
     * Validates if a tile can be placed at the specified position on the board.
     *
     * @param board the board on which the tile is to be placed
     * @param tile  the tile to be placed
     * @param row   the row position of the tile
     * @param col   the column position of the tile
     * @return true if the tile can be placed, false otherwise
     */
    public static boolean isValidTilePlacement(Board board, Tile tile, int row, int col) {
        Objects.requireNonNull(board, "Board must not be null");
        Objects.requireNonNull(tile, "Tile cannot be null");

        if (row < 0 || row >= board.getRows() || col < 0 || col >= board.getCols()) {
            return false;
        }

        if (board.getTile(row, col) != null) {
            return false;
        }

        for (int[] direction : new int[][]{{0, 1}, {1, 0}, {0, -1}, {-1, 0}}) {
            var adjRow = row + direction[0];
            var adjCol = col + direction[1];
            var adjacentTile = board.getTile(adjRow, adjCol);
            if (adjacentTile != null) {
                return true;
            }
        }

        return false;
    }

    /**
     * Validates if a tile can be placed at the specified position on the board with hexagonal adjacency.
     *
     * @param board the board on which the tile is to be placed
     * @param tile  the tile to be placed
     * @param row   the row position of the tile
     * @param col   the column position of the tile
     * @return true if the tile can be placed, false otherwise
     */
    public static boolean isValidTilePlacementHex(Board board, Tile tile, int row, int col) {
        Objects.requireNonNull(board, "Board must not be null");
        Objects.requireNonNull(tile, "Tile cannot be null");

        if (row < 0 || row >= board.getRows() || col < 0 || col >= board.getCols()) {
            return false;
        }

        if (board.getTile(row, col) != null) { // isPresent()
            return false;
        }

        for (int[] direction : new int[][]{{0, 2}, {0, -2}, {1, 1}, {-1, 1}, {1, -1}, {-1, -1}}) {
            var adjRow = row + direction[0];
            var adjCol = col + direction[1];
            var adjacentTile = board.getTile(adjRow, adjCol);
            if (adjacentTile != null) {
                return true;
            }
        }

        return false;
    }

    /**
     * Validates if an animal can be placed on the specified tile.
     *
     * @param tile   the tile where the animal is to be placed
     * @param animal the animal to be placed
     * @return true if the animal can be placed, false otherwise
     */
    public static boolean isValidAnimalPlacement(Tile tile, AnimalType animal) {
        Objects.requireNonNull(animal, "Animal cannot be null");

        if (tile == null) {
            return false;
        }

        if (!tile.getAcceptedAnimals().contains(animal)) {
            return false;
        }

      return tile.getCurrentlyPlacedAnimal() == null;
    }
}