package fr.uge.projet.engine;

/**
 * Enum representing different types of areas on the game board.
 */
public enum AreaType {
	WETLAND, FOREST, MOUNTAIN, RIVER, PRAIRIE
}