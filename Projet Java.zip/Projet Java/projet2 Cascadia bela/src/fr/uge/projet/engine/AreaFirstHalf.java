package fr.uge.projet.engine;


/**
 * Enum representing different types of combined areas on the game board.
 */
public enum AreaFirstHalf {
  FOREST_PRAIRIE, 
  FOREST_RIVER,
  FOREST_MOUNTAIN,
  FOREST_WETLAND,
  MOUNTAIN_FOREST,
  MOUNTAIN_PRARIE,
  MOUNTAIN_SWAMP,
  PRAIRIE_RIVER,
  PRAIRIE_WETLAND,
  MOUNTAIN_PRAIRIE,
  
  PRAIRIE_PRAIRIE,
  MOUNTAIN_MOUNTAIN,
  FOREST_FOREST,
  RIVER_RIVER,
  WETLAND_WETLAND,
  
  
  WETLAND_RIVER;
}