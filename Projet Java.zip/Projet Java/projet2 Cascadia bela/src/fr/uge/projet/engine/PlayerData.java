package fr.uge.projet.engine;

import fr.uge.projet.engine.AnimalType;
import fr.uge.projet.engine.Tile;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * PlayerData class contains information about a player's progress in the game.
 * It includes the player's score, selected tile and animal, and options for drawing tiles and animals.
 */
public class PlayerData {
  private final String name;
  private final Board board;
  private int score;
  private Tile selectedTile;
  private AnimalType selectedAnimal;
  private final List<Tile> drawTilesOptions;
  private final List<AnimalType> drawAnimalOptions;
  private boolean tilePlaced;
  private boolean canPlaceAnimal;

  /**
   * Constructs a new PlayerData object for the specified player.
   *
   * @param name  the name of the player
   * @param board the board associated with the player
   */
  public PlayerData(String name, Board board) {
    this.name = Objects.requireNonNull(name, "Name must not be null");
    this.board = Objects.requireNonNull(board, "Board must not be null");
    this.drawTilesOptions = new ArrayList<>();
    this.drawAnimalOptions = new ArrayList<>();
    this.score = 0;
    this.tilePlaced = false;
  }

  /**
   * Gets the name of the player associated with this data.
   *
   * @return the name of the player
   */
  public String getName() {
    return name;
  }

  public boolean isTilePlaced() {
    return tilePlaced;
  }

  public void setTilePlaced(boolean tilePlaced) {
    this.tilePlaced = tilePlaced;
  }

  /**
   * Gets the score of the player associated with this data.
   *
   * @return the score of the player
   */
  public int getScore() {
    return score;
  }

  /**
   * Gets the board associated with the player.
   *
   * @return the Board object representing the player's board
   */
  public Board getBoard() {
    return board;
  }

  /**
   * Gets the selected tile by the player.
   *
   * @return the selected Tile object
   */
  public Tile getSelectedTile() {
    return selectedTile;
  }

  /**
   * Sets the selected tile for the player.
   *
   * @param selectedTile the tile to be selected
   */
  public void setSelectedTile(Tile selectedTile) {
    this.selectedTile = selectedTile;
  }

  public boolean canPlaceAnimal() {
    return canPlaceAnimal;
  }

  public void setCanPlaceAnimal(boolean canPlaceAnimal) {
    this.canPlaceAnimal = canPlaceAnimal;
  }

  /**
   * Gets the selected animal by the player.
   *
   * @return the selected AnimalType
   */
  public AnimalType getSelectedAnimal() {
    return selectedAnimal;
  }

  /**
   * Sets the selected animal for the player.
   *
   * @param selectedAnimal the animal to be selected
   */
  public void setSelectedAnimal(AnimalType selectedAnimal) {
    this.selectedAnimal = selectedAnimal;
  }

  /**
   * Gets the list of available tiles for the player to draw.
   *
   * @return a list of available Tile objects
   */
  public List<Tile> getDrawTilesOptions() {
    return drawTilesOptions;
  }

  /**
   * Gets the list of available animals for the player to draw.
   *
   * @return a list of available AnimalType objects
   */
  public List<AnimalType> getDrawAnimalOptions() {
    return drawAnimalOptions;
  }

  /**
   * Changes the player's score by the specified value.
   *
   * @param value the value to change the score by
   */
  public void changeScore(int value) {
    score += value;
  }

  /**
   * Returns a string representation of the player's data.
   *
   * @return a string representing the player's data
   */
  @Override
  public String toString() {
    return "PlayerData{" +
            "name='" + name + '\'' +
            ", score=" + score +
            ", board=" + board +
            '}';
  }
}