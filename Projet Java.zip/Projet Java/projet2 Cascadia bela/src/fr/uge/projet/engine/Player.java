package fr.uge.projet.engine;


/**
 * Player class represents a player in the game.
 * It stores the player's name, board, score, and data.
 */

import java.util.Objects;

/**
 * Player class represents a player in the game.
 * It stores the player's name, board, score, and data.
 */
public class Player {
  private final String name;
  private final Board board;
  private int score;
  private final PlayerData data;

  /**
   * Constructs a new Player with the specified name and board.
   *
   * @param name  the name of the player
   * @param board the board associated with the player
   */
  public Player(String name, Board board) {
    this.name = Objects.requireNonNull(name, "Name must not be null");
    this.board = Objects.requireNonNull(board, "Board must not be null");
    this.data = new PlayerData(name, board);
  }

  /**
   * Gets the data associated with the player.
   *
   * @return the PlayerData object containing the player's data
   */
  public PlayerData getData() {
    return data;
  }

  /**
   * Gets the name of the player.
   *
   * @return the name of the player
   */
  public String getName() {
    return name;
  }

  /**
   * Gets the score of the player.
   *
   * @return the score of the player
   */
  public int getScore() {
    return score;
  }

  /**
   * Gets the board associated with the player.
   *
   * @return the Board object representing the player's board
   */
  public Board getBoard() {
    return board;
  }

  /**
   * Changes the player's score by the specified value.
   *
   * @param value the value to change the score by
   */
  public void changeScore(int value) {
    score += value;
  }

  /**
   * Attempts to place a tile on the board at the specified position.
   *
   * @param tile           the tile to be placed
   * @param row            the row where the tile should be placed
   * @param col            the column where the tile should be placed
   * @param atInitialisation flag indicating whether the placement is during initialization
   * @return true if the tile was placed successfully, false otherwise
   */
  public boolean placeTile(Tile tile, int row, int col, int atInitialisation) {
    return board.placeTile(row, col, tile, atInitialisation);
  }

  /**
   * Attempts to place an animal on the board at the specified position.
   *
   * @param board  the board where the animal should be placed
   * @param row    the row where the animal should be placed
   * @param col    the column where the animal should be placed
   * @param animal the type of animal to be placed
   * @return true if the animal was placed successfully, false otherwise
   */
  public boolean placeAnimal(Board board, int row, int col, AnimalType animal) {
    if (board.placeAnimal(row, col, animal)) {
      // Scoring logic can be tied here if placement affects the score
      return true;
    }
    return false;
  }

  /**
   * Displays the player's details including name, score, and the size of the board.
   *
   * @return a string representation of the player's details
   */
  @Override
  public String toString() {
    var cols = board.getCols();
    var rows = board.getRows();
    return "Player{" +
            "name='" + name + '\'' +
            ", score=" + score +
            ", tiles size=" + cols + " , " + rows +
            '}';
  }
}
