package fr.uge.testing;
import java.util.ArrayList;

public class Main {
    // Point record class
    public record Point(int x, int y) {}

    public static void main(String[] args) {
        // Sample input: ArrayList of Points
        ArrayList<Point> arrayOfPoints = new ArrayList<>();
        arrayOfPoints.add(new Point(0, 0));
        arrayOfPoints.add(new Point(0, 1));
        arrayOfPoints.add(new Point(1, 1));
        
        arrayOfPoints.add(new Point(0, 6));  // Not adjacent
        arrayOfPoints.add(new Point(1, 6));
        arrayOfPoints.add(new Point(2, 6));
        arrayOfPoints.add(new Point(3, 6));

        System.out.println(" Longest chain length: " + longestAdjacentChain(arrayOfPoints));
    }

    // Method to find the length of the longest chain of adjacent points
    public static int longestAdjacentChain(ArrayList<Point> points) {
        if (points == null || points.size() == 0) {
            return 0;
        }

        int maxLength = 1;
        int currentLength = 1;

        for (int i = 1; i < points.size(); i++) {
            Point prev = points.get(i - 1);
            Point curr = points.get(i);

            // Check if the current point is adjacent to the previous one
            if (isAdjacent(prev, curr)) {
                currentLength++;
            } else {
                // If they are not adjacent, reset the current chain length
                currentLength = 1;
            }

            // Update max length if current chain is longer
            maxLength = Math.max(maxLength, currentLength);
        }

        return maxLength;
    }

    // Method to check if two points are adjacent
    public static boolean isAdjacent(Point p1, Point p2) {
        // Adjacent if they are either one unit apart horizontally or vertically
        return (Math.abs(p1.x() - p2.x()) == 1 && p1.y() == p2.y()) || 
               (Math.abs(p1.y() - p2.y()) == 1 && p1.x() == p2.x());
    }
}
