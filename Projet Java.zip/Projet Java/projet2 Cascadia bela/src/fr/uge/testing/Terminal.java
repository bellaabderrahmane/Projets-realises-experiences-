package fr.uge.testing;

import fr.uge.projet.engine.Tile;

public class Terminal {

    // Draw a single tile (handles null and non-null tiles)
	/*
    public void drawIndividualTile(Tile tile) {
        String top = "+----------+";
        String middle;
        String allowedAnimalsFirst;
        String allowedAnimalsSecond;
        String animalLine;
        String bottom = "+----------+";

        if (tile != null) {
            String terrainSymbol = tile.getAreaType().get(0).name();
            middle = formatLine(terrainSymbol);

            String allowedAnimalFirst = tile.getAcceptedAnimals().get(0).name();
            allowedAnimalsFirst = formatLine(allowedAnimalFirst);

            String allowedAnimalSecond = tile.getAcceptedAnimals().get(1).name();
            allowedAnimalsSecond = formatLine(allowedAnimalSecond);

            String animalSymbol = tile.getCurrentlyPlacedAnimal() != null ?
                    tile.getCurrentlyPlacedAnimal().name() : "XXX";
            animalLine = formatLine(animalSymbol);
        } else {
            // For null tiles, draw a placeholder
            middle = formatLine(" ");
            allowedAnimalsFirst = formatLine(" ");
            allowedAnimalsSecond = formatLine(" ");
            animalLine = formatLine(" ");
        }

        System.out.println(top);
        System.out.println(middle);
        System.out.println(allowedAnimalsFirst);
        System.out.println(allowedAnimalsSecond);
        System.out.println(animalLine);
        System.out.println(bottom);
    }*/

    // Draw a grid of tiles, including null tiles adjacent to non-null tiles
    public void drawBoard(Tile[][] board) {
        for (int row = 0; row < board.length; row++) {
            StringBuilder topRow = new StringBuilder();
            StringBuilder middleRow = new StringBuilder();
            StringBuilder allowedAnimalsFirstRow = new StringBuilder();
            StringBuilder allowedAnimalsSecondRow = new StringBuilder();
            StringBuilder animalLineRow = new StringBuilder();
            StringBuilder bottomRow = new StringBuilder();

            for (int col = 0; col < board[row].length; col++) {
                Tile tile = board[row][col];
                // Include null tiles adjacent to non-null tiles
                if (tile != null || hasAdjacentNonNullTile(board, row, col)) {
                    topRow.append("+----------+");
                    String terrainSymbol = tile != null ? tile.getAreaType().get(0).name() : " ";
                    middleRow.append(formatLine(terrainSymbol));
                   
                    String allowedAnimalFirst = tile != null ? tile.getAcceptedAnimals().get(0).name() : " ";
                    allowedAnimalsFirstRow.append(formatLine(allowedAnimalFirst));
                    String allowedAnimalSecond = tile != null ? tile.getAcceptedAnimals().get(1).name() : " ";
                    allowedAnimalsSecondRow.append(formatLine(allowedAnimalSecond));
                    String animalSymbol = (tile != null && tile.getCurrentlyPlacedAnimal() != null) ?
                            tile.getCurrentlyPlacedAnimal().name() : " ";
                    animalLineRow.append(formatLine(animalSymbol));
                    bottomRow.append("+----------+");
                }
            }

            System.out.println(topRow);
            System.out.println(middleRow);
            System.out.println(allowedAnimalsFirstRow);
            System.out.println(allowedAnimalsSecondRow);
            System.out.println(animalLineRow);
            System.out.println(bottomRow);
        }
    }

    // Helper method to format a line with fixed width
 // Helper method to format a line with dynamic width padding to match the top
    private StringBuilder formatLine(String content) {
        // Construct the formatted line3
    	var filler = new StringBuilder();;
        return filler.append("| ").append(content).repeat(" ",12-content.length()-4).append(" |");
    }


    // Checks if a null tile is adjacent to a non-null tile
    private boolean hasAdjacentNonNullTile(Tile[][] board, int row, int col) {
        int[] rowOffsets = {-1, 1, 0, 0};
        int[] colOffsets = {0, 0, -1, 1};
        for (int i = 0; i < 4; i++) {
            int adjRow = row + rowOffsets[i];
            int adjCol = col + colOffsets[i];

            if (adjRow >= 0 && adjRow < board.length && adjCol >= 0 && adjCol < board[0].length) {
                if (board[adjRow][adjCol] != null) {
                    return true;
                }
            }
        }
        return false;
    }
}
