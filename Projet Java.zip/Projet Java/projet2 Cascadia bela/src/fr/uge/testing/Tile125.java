package fr.uge.testing;
//import java.util.HashSet;
//import java.util.Set;

public class Tile125 {
    public enum Habitat {
        FOREST, WETLAND, MOUNTAIN, DESERT, LAKE, PRAIRIE
    }

    // Habitat types on each side of the hexagon
    public Habitat[] sides;  // This is the array representing the 6 sides of the hexagon

    // Constructor for a tile with two habitats (will be distributed across sides)
    public Tile125(Habitat habitat1, Habitat habitat2) {
        sides = new Habitat[6];

        // Assign the habitats to the appropriate sides
        // Let's assume habitat1 goes to the right side and habitat2 goes to the left side
        sides[0] = habitat1;  // Top-right
        sides[1] = habitat1;  // Right
        sides[2] = habitat2;  // Bottom-right
        sides[3] = habitat2;  // Bottom-left
        sides[4] = habitat1;  // Left
        sides[5] = habitat2;  // Top-left
    }

    // Method to rotate the tile clockwise (right)
    public void rotateRight() {
        Habitat temp = sides[5];
        for (int i = 5; i > 0; i--) {
            sides[i] = sides[i - 1];
        }
        sides[0] = temp;
    }

    // Method to rotate the tile counter-clockwise (left)
    public void rotateLeft() {
        Habitat temp = sides[0];
        for (int i = 0; i < 5; i++) {
            sides[i] = sides[i + 1];
        }
        sides[5] = temp;
    }
/*
    // Method to check if two tiles share the same habitat on their adjacent sides
    public boolean isAdjacent(Tile other, int sideIndex) {
        // Check for matching habitats on adjacent sides
        int nextSide = (sideIndex + 1) % 6;  // This handles the cyclic nature of the hexagon
        return sides[sideIndex] == other.sides[nextSide];
    }*/

    // Method to check the habitat type on a specific side of the hexagon
    public Habitat getSideHabitat(int sideIndex) {
        return sides[sideIndex];
    }

    // Method to print tile for debugging
    public void printTile() {
        System.out.println("Tile sides: ");
        for (int i = 0; i < 6; i++) {
            System.out.println("Side " + i + ": " + sides[i]);
        }
    }
}
