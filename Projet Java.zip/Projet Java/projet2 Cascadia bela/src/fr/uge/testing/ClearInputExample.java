package fr.uge.testing;
import java.util.Scanner;

public class ClearInputExample {

    public static void main(String[] args) throws InterruptedException {
        // Print the prompt
        System.out.print("Write something: ");
        
        // Create a scanner to get input
        Scanner scanner = new Scanner(System.in);
        String userInput = scanner.nextLine();
        
        // Pause briefly so the user can see what they've written
        Thread.sleep(500); // Optional: Delay for half a second for better UX
        
        // Clear the terminal screen (works on most systems)
        // ANSI escape codes to clear screen
        System.out.print("\033[H\033[2J");
        System.out.flush();
        
        // Display the user input after clearing
        System.out.println("Your input is: " + userInput);
        
        // Close the scanner
        scanner.close();
    }
}
