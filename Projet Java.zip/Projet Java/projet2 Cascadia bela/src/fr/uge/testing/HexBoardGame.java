package fr.uge.testing;
public class HexBoardGame { //for graphic placements
    private static final int BOARD_SIZE = 5; // Example size
    private static String[][] board = new String[BOARD_SIZE][BOARD_SIZE];

    // Directions for a hexagonal grid (offset coordinate system)
    // For a tile at (r, c), the neighbors are defined by these directions:
    // {Up-left, Up-right, Left, Right, Down-left, Down-right}
    private static final int[] dr = {-1, -1, 0, 0, 1, 1};
    private static final int[] dc = {-1, 1, -1, 1, -1, 1};

    public static void main(String[] args) {
        // Sample moves
        placeX(2, 2); // Place X at (2, 2)
        placeX(2, 3); // Place X at (2, 3)
        placeX(3, 3); // Place X at (3, 3)
        placeX(1, 2); // Place X at (1, 2)

        // Attempting an invalid move (adjacent to (2, 3))
        placeX(2, 2); // Invalid, already an X there
    }

    // Method to place an X at a given row and column
    public static void placeX(int row, int col) {
        if (isAdjacentToAnotherX(row, col)) {
            System.out.println("Can't place X at (" + row + ", " + col + ") - Adjacent to another X!");
        } else {
            board[row][col] = "X";
            System.out.println("Placed X at (" + row + ", " + col + ")");
        }
    }

    // Method to check if a given cell is adjacent to an existing X
    public static boolean isAdjacentToAnotherX(int row, int col) {
        // Check if the current cell is already occupied by an X
        if (board[row][col] != null && board[row][col].equals("X")) {
            return true; // This cell already has an X
        }

        // Check all 6 directions (neighbors)
        for (int i = 0; i < 6; i++) {
            int neighborRow = row + dr[i];
            int neighborCol = col + dc[i];

            // Ensure the neighbor is within bounds of the board
            if (isValidPosition(neighborRow, neighborCol) && board[neighborRow][neighborCol] != null && board[neighborRow][neighborCol].equals("X")) {
                return true; // Found an adjacent X
            }
        }

        // No adjacent X found
        return false;
    }

    // Helper method to check if the position is within bounds of the board
    public static boolean isValidPosition(int row, int col) {
        return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
    }
}
