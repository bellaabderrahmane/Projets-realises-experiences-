package fr.uge.testing;
public class TileInitializer {
    public static void main(String[] args) {
        String[][] tiles = new String[3][7];
        initializeTiles(tiles);
        printTiles(tiles);
    }

    public static void initializeTiles(String[][] tiles) {
        for (int row = 0; row < tiles.length; row++) {
            for (int col = 0; col < tiles[row].length; col++) {
                // Odd rows have an offset
                if (row % 2 == 1) {
                    if (col % 2 == 0) {
                        tiles[row][col] = "x";
                    } else {
                        tiles[row][col] = "R";
                    }
                } else { // Even rows
                    if (col % 2 == 0) {
                        tiles[row][col] = "R";
                    } else {
                        tiles[row][col] = "x";
                    }
                }
            }
        }
    }

    public static void printTiles(String[][] tiles) {
        for (String[] row : tiles) {
            for (String cell : row) {
                System.out.print(cell);
            }
            System.out.println();
        }
    }
}
