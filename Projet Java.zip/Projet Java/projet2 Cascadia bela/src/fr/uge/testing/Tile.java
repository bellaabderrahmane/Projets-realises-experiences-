package fr.uge.testing;
import java.util.Arrays;

public class Tile {
    public enum Habitat {
        FOREST, WETLAND, MOUNTAIN, DESERT, LAKE, PRAIRIE
    }

    // Array for storing the habitats on each side of the hexagon
    private Habitat[] sides;

    // Constructor for a tile with a single habitat (Option 1)
    public Tile(Habitat habitat, int option) {
        // If option is 1, all sides get the same habitat
        if (option == 1) {
            sides = new Habitat[6];
            Arrays.fill(sides, habitat);  // All sides are the same habitat
        }
        // If option is 2, the tile gets two habitats, and we assign to sides
        else if (option == 2) {
            sides = new Habitat[6];
            // Assign the first habitat to the appropriate sides
            sides[0] = habitat; // Top-right
            sides[1] = habitat; // Right
            sides[2] = habitat; // Bottom-right
            sides[3] = habitat; // Bottom-left
            sides[4] = habitat; // Left
            sides[5] = habitat; // Top-left

            // Now fill the other sides with the second habitat
            // Let's assume the second habitat is passed as another parameter or default
            Habitat secondHabitat = (habitat == Habitat.FOREST) ? Habitat.WETLAND : Habitat.FOREST;
            sides[2] = secondHabitat; // Bottom-right
            sides[3] = secondHabitat; // Bottom-left
        }
    }

    // Method to rotate the tile clockwise (right)
    public void rotateRight() {
        Habitat temp = sides[5];
        for (int i = 5; i > 0; i--) {
            sides[i] = sides[i - 1];
        }
        sides[0] = temp;
    }

    // Method to rotate the tile counter-clockwise (left)
    public void rotateLeft() {
        Habitat temp = sides[0];
        for (int i = 0; i < 5; i++) {
            sides[i] = sides[i + 1];
        }
        sides[5] = temp;
    }

    // Method to print tile for debugging
    public void printTile() {
        System.out.println("Tile sides: ");
        for (int i = 0; i < 6; i++) {
            System.out.println("Side " + i + ": " + sides[i]);
        }
    }

    // Example method to get habitat on a specific side
    public Habitat getSideHabitat(int sideIndex) {
        return sides[sideIndex];
    }
}
