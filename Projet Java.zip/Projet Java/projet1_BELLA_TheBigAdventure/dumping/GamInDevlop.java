package fr.umlv.zelda.main;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JComponent;

import fr.umlv.zelda.display.Amis;
import fr.umlv.zelda.display.Element;
import fr.umlv.zelda.display.Encoding;
import fr.umlv.zelda.display.Enemis;
import fr.umlv.zelda.display.Item;
import fr.umlv.zelda.display.Obstacle;
import fr.umlv.zelda.display.Player;
import fr.umlv.zelda.display.Position;
import fr.umlv.zelda.lexer.MapReader;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.Event.Action;
import fr.umlv.zen5.KeyboardKey;
import fr.umlv.zen5.ScreenInfo;

public class GamInDevlop {
	
	private boolean updateEnemies = false;


	private boolean waitForImage(Image image) {
    Component dummyComponent = new Component() {};
    MediaTracker tracker = new MediaTracker(dummyComponent);
    tracker.addImage(image, 0);
    try {
        tracker.waitForAll();
    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        return false;
    }
    return !tracker.isErrorAny();
	}
	
	public void displayObject(String objectskin,Position postion,int picturewidth,Graphics graphics) {
		Image image = Toolkit.getDefaultToolkit().getImage("img/" + objectskin + ".png");
		if (waitForImage(image)) {
			graphics.drawImage(image, postion.x() , postion.y() , picturewidth, picturewidth, null);
	  } else {
	      System.out.println("Image loading failed.");
	  }
	}

	public void displayMap(ApplicationContext context, List<Obstacle> obstacles,List<Item> items,List<Enemis> enemies,List<Amis> friends,Player player, int xix) {
		context.renderFrame(graphics -> {
			displayObject(player.skin(),player.pos(),xix, graphics);
			for (var elm : obstacles) {
				displayObject(elm.skin(),elm.pos(),xix, graphics);
			}
			for (var elm : items) {
				displayObject(elm.skin(),elm.pos(),xix, graphics);
			}
			for (var elm : enemies) {
				displayObject(elm.skin(),elm.pos(),xix, graphics);
			}
			for (var elm : friends) {
				displayObject(elm.skin(),elm.pos(),xix, graphics);
			}
		});
	}
	
	
	
	public boolean EntityCanMove(List<Obstacle> obstacles,List<Amis> friends,List<Enemis> enemies,Player player ,int x , int y,int xix) {
		var futureposition = new Position(player.pos().x()+x, player.pos().y()+y);
		for(var s : obstacles ) {
			if(s.pos().equals(futureposition) && !s.passable()) {
				return false ;
			}
		}
		for(var s : friends ) {
			if(s.pos().equals(futureposition) ) {
				return false ;
			}
		}
		for(var s : enemies ) {
			if(s.pos().equals(futureposition) ) {
				return false ;
			}
		}
		return true ;
	}
	
	
	public void displayMoveEntity(ApplicationContext context,Player player ,int xix,List<Obstacle> obstacles,Position oldposition) {
		context.renderFrame(graphics -> {
			for(var s : obstacles) {
				if(s.pos().equals(oldposition) ) {
					displayObject(s.skin(),oldposition,xix, graphics);
				}
			}
			Color myColor = new Color(224, 224, 224);
			graphics.setColor(myColor);
			graphics.fillRect(oldposition.x()*xix, oldposition.y()*xix, xix, xix);
			displayObject(player.skin(),player.pos(),xix, graphics);
		});
	}	
	
	public Player moveEntity(ApplicationContext context,List<Obstacle> obstacles,Player player ,int x , int y,int xix) {
		Position oldposition = player.pos() ;
		player =  new Player(player.name(), new Position(player.pos().x()+x, player.pos().y()+y), player.skin(), player.isPlayer(), player.health(), player.phantomized());
		displayMoveEntity( context, player , xix,obstacles,oldposition);
		return player ;
	}
	
	
	
	
	public Player playerMove(ApplicationContext context,List<Obstacle> obstacles,List<Amis> friends,List<Enemis> enemies,Player player ,Event event,int xix) {
		if (event == null) {
			return player; 
		}
		Action action = event.getAction();
		if (action == Action.KEY_PRESSED) {
			switch (event.getKey()) {
			case RIGHT -> {
				if(EntityCanMove(obstacles,friends,enemies,player ,1 ,0,xix)) {
					player =moveEntity(context,obstacles,player ,1 , 0,xix);
				}
			}
			case LEFT -> {
				if(EntityCanMove(obstacles,friends,enemies,player ,-1 , 0,xix)) {
				player = moveEntity(context,obstacles,player ,-1 , 0,xix);}
			}
			case UP -> {
				if(EntityCanMove(obstacles,friends,enemies,player ,0 , -1,xix)) {
				player = moveEntity(context,obstacles,player ,0 , -1,xix);}
			}
			case DOWN -> {
				if(EntityCanMove(obstacles,friends,enemies,player ,0 , 1,xix)) {
				player = moveEntity(context,obstacles,player ,0 , 1,xix);}
			}
			default -> xix = xix;
			}
		}
		return player ;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void displayMoveEnemy(Graphics graphics,Enemis enemy ,int xix,List<Obstacle> obstacles,Position oldposition) {
		
			for(var s : obstacles) {
				if(s.pos().equals(oldposition) ) {
					displayObject(s.skin(),oldposition,xix, graphics);
				}
			}
			Color myColor = new Color(224, 224, 224);
			graphics.setColor(myColor);
			graphics.fillRect(oldposition.x()*xix, oldposition.y()*xix, xix, xix);
			displayObject(enemy.skin(),enemy.pos(),xix, graphics);
		
	}	
	
	
	public boolean EnemyCanMove(List<Obstacle> obstacles,List<Amis> friends,List<Enemis> enemies,Enemis enemy ,Player player ,int x , int y,int xix) {
		var futureposition = new Position(enemy.pos().x()+x, enemy.pos().y()+y);
		if(player.pos().equals(futureposition)) {
			return false ;
		}
		
		if(enemy.behavior() == null ) {
			return false ;
		}
		
		for(var s : obstacles ) {
			if(s.pos().equals(futureposition) && !s.passable()) {
				return false ;
			}
		}
		for(var s : friends ) {
			if(s.pos().equals(futureposition) ) {
				return false ;
			}
		}
		for(var s : enemies ) {
			if(s.pos().equals(futureposition) ) {
				return false ;
			}
		}
		return true ;
	}
	
	
	
	public List<Enemis> moveEnemy(ApplicationContext context,List<Enemis> enemies,List<Obstacle> obstacles,List<Amis> friends,Player player ,int xix) {
		context.renderFrame(graphics -> {
		for (int i = 0; i < enemies.size(); i++) {
      Enemis enemy = enemies.get(i);
      Enemis movedenemy = enemy;
  		Random random = new Random();
  		int x = random.nextInt(3) - 1;
  		int y = random.nextInt(3) - 1;
  		if(EnemyCanMove(obstacles,friends,enemies,enemy,player ,x ,y,xix)) {
  			var newposition = new Position( enemy.pos().x() + x , enemy.pos().y() + y );
  		  movedenemy = new Enemis(enemy.name(),enemy.skin(),newposition,enemy.health(),enemy.zone(),enemy.behavior(),enemy.damage(),enemy.kind(),enemy.phantomized());
  		  displayMoveEnemy(graphics,movedenemy ,xix,obstacles,enemy.pos());
  		}
      enemies.set(i, movedenemy); // Update the list with the new enemy object
		}
		});
		return enemies ;
	}
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void quitGame(ApplicationContext context,Event event) {
		if (event == null) {
			return; 
		}
		Action action = event.getAction();
		if ((action == Action.KEY_PRESSED && event.getKey() == KeyboardKey.Q) ) {
			System.out.println("Touche Q appuyée, sortie de l'application");
			context.exit(0);
			return;
		}
	}
	

	public static void main(String[] args) throws IOException {

		var text = Files.readString(Path.of("maps/test.map"));
		MapReader mapy = new MapReader(text);
		GamInDevlop game = new GamInDevlop();
		Color myColor = new Color(224, 224, 224);
		Application.run(myColor, context -> {
			
			
			List<Item> items = mapy.getItems();
			List<Enemis> enemies = mapy.getEnemy();
			List<Amis> friends = mapy.getFriend();
			List<Obstacle> obstacles = mapy.getObstacles();
			int pace = 0 ;
			
			Timer enemyMovementTimer = new Timer();
			TimerTask enemyMovementTask = new TimerTask() {
				@Override
				public void run() {
					game.updateEnemies = true;
				}
			};
			enemyMovementTimer.scheduleAtFixedRate(enemyMovementTask, 0, 700);
			
			
			String[] yix = null;
			yix = mapy.getSize();
			ScreenInfo screenInfo = context.getScreenInfo();
			float width = screenInfo.getWidth();
			float height = screenInfo.getHeight();
			int xix = (int) Math.min(width / Integer.parseInt(yix[0].trim()), height / Integer.parseInt(yix[1].trim()));
			pace = xix / 2 ;
			Player player = mapy.getPlayer() ;
			game.displayMap( context, obstacles, items,enemies,friends,player, xix);
				
			while (true) {
				Event event = context.pollOrWaitEvent(50);
				game.quitGame( context, event);
				
				
				if (game.updateEnemies) {
					enemies = game.moveEnemy(context, enemies, obstacles, friends, player, xix); 
					game.updateEnemies = false ;
				}
				
				player = game.playerMove(context,obstacles,friends,enemies,player ,event,xix);
			}
			
			
		});
		
	}
}