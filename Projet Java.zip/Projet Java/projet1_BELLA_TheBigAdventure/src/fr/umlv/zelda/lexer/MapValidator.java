package fr.umlv.zelda.lexer;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import fr.umlv.zelda.display.Position;
import fr.umlv.zelda.display.Zone;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

public class MapValidator {
  private final Lexer lexer;

  public MapValidator(String text) throws IOException {
      this.lexer = new Lexer(text);
  }

  public boolean validate() {
      Result result;
      while ((result = lexer.nextResult()) != null) {
      	

          if (result.isToken(Token.IDENTIFIER) && result.content().equals("size")) {
              if (!isValidSizeFormat()) {
                  return false;
              }
          }
          
	      	if (result.isToken(Token.IDENTIFIER) && result.content().equals("encodings")) {
	          if (!isValidEncodingsFormat()) {
	          		return false;
	          }
		      }
	      	
	      	if (result.isToken(Token.LEFT_BRACKET) ) {
	      		result = expectNewline();
	      		if (result.isToken(Token.IDENTIFIER) && result.content().equals("element")) {
	      			result = expectNewline();
	      			if (result.isToken(Token.RIGHT_BRACKET) ) {
	      				if ( !isValidElementFormat() ) {
		          		return false;
	      				}
	      			}
	      		}
		      }
          
          
      }
      return true;
  }

  
  
  
  
  
  

  
  
  
  
  
  
  
  
  
  
  
  
  private boolean isValidElementFormat() {
  	Result result = expectNewline();
  	
  
  	while ( result  != null ) {
     
	  	switch (result.content()) {
	
			case "player":
	
				break;
	
			case "name":
	
				break;
	
			case "skin":
	
				break;
	
			case "position":
	
				break;
	
			case "health":
	
				break;
	
			case "zone":
	
				break;
	
			case "behavior":
			
				break;
	
			case "damage":
			
				break;
	
			case "kind":
			
				break;
	
			case "steal":
				
				break;
	
			case "phantomized":
			
				break;
	  	}
	  	
  	
  	
  	
  	}
	return true;
  	

  }
  
  
  
  
  
  
  
  
  
  
  
  private boolean isStopToken(Result result) {
    return result.isToken(Token.IDENTIFIER) && 
           (result.content().equals("size") || result.content().equals("data") || result.content().equals("[element]"));
  }
  
  private boolean isAllUpperCase(String content) {
    return content.matches("[A-Z]+");
  }
  
  private boolean isSingleLetter(String content) {
    return content.matches("[A-Za-z]");
  }

  private boolean isValidEncodingsFormat() {
  	Result result = expectNewline();
  	if (!result.isToken(Token.COLON)) {
      return false;
  	}
    while (true) { 

		    	if (result == null || isStopToken(result)) {
		        return true;
		      }
		    	result = isValidfomat() ;
		    	
	        if( result  ==null ) {
	        	return false ;
	        }   
    }
  }
  
  private Result isValidfomat() {
  	Result result = expectNewline();
  	
  	if (!result.isToken(Token.IDENTIFIER) || !isAllUpperCase(result.content())) {
  		return null;
  	}
  	
  	result = expectNewline();
  	
  	if (!result.isToken(Token.LEFT_PARENS) ) {
  		return null;
  	}
  	
  	result = expectNewline();
  	
  	if (!result.isToken(Token.IDENTIFIER) || !isSingleLetter(result.content())) {
  		return null;
  	}

  	result = expectNewline();
  	if (!result.isToken(Token.RIGHT_PARENS) ) {
  		return null;
  	}
  	
  	result = expectNewline();
    return result;
   
  }
  
  
  
  
  
  
  
  
  
  
  
  private boolean isValidSizeFormat() {
      return expectToken(Token.COLON)  &&
             expectToken(Token.LEFT_PARENS) && 
             expectToken(Token.NUMBER) && 
             expectToken(Token.IDENTIFIER, "x") && 
             expectToken(Token.NUMBER) && 
             expectToken(Token.RIGHT_PARENS);
  }

  private boolean expectToken(Token expectedToken) {
      Result result = lexer.nextResult();
      while ( result.isToken(Token.NEWLINE) ) {
       result = lexer.nextResult();
      }
      
      return result != null && result.isToken(expectedToken);
  }

  private boolean expectToken(Token expectedToken, String expectedContent) {
      Result result = lexer.nextResult();
      while ( result.isToken(Token.NEWLINE) ) {
        result = lexer.nextResult();
       }
      return result != null && result.isToken(expectedToken) && result.content().equals(expectedContent);
  }

  private Result expectNewline() {
      Result result;
      while ((result = lexer.nextResult()) != null) {
          if (!result.isToken(Token.NEWLINE) ) {
              break;
          }
      }
      return result ;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  public static void main(String[] args) {
    try {
        String mapContent = Files.readString(Path.of("maps/test.map")); // Read the map file
        MapValidator validator = new MapValidator(mapContent);

        boolean isValid = validator.validate(); // Validate the map

        if (isValid) {
            System.out.println("The map is valid.");
        } else {
            System.out.println("The map is invalid.");
        }
    } catch (IOException e) {
        System.err.println("Error reading the map file: " + e.getMessage());
    }
}
}
