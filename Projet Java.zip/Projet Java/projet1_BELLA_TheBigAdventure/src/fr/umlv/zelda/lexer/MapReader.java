package fr.umlv.zelda.lexer;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import fr.umlv.zelda.display.Amis;
import fr.umlv.zelda.display.Element;
import fr.umlv.zelda.display.Encoding;
import fr.umlv.zelda.display.Enemis;
import fr.umlv.zelda.display.Item;
import fr.umlv.zelda.display.Obstacle;
import fr.umlv.zelda.display.Player;
import fr.umlv.zelda.display.Position;
import fr.umlv.zelda.display.Size;
import fr.umlv.zelda.display.Zone;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.ScreenInfo;

public class MapReader {
	private final Lexer lexer;
	private final HashMap<String, String> encodings = new HashMap<>();
	private ArrayList<Encoding> positions = new ArrayList<>();
	private List<Element> elements = new ArrayList<>();
	
	private final List<Item> items = new ArrayList<>();
	private final List<Enemis> enemies = new ArrayList<>();
	private final List<Amis> friends = new ArrayList<>();
	private final List<Obstacle> obstacles = new ArrayList<>();
	private Player playeringame ;
	
	
	private String[] size = new String[2];
	private Size sizemap ;
	private int xix = 1 ;

	public MapReader(String text) throws IOException {
		this.lexer = new Lexer(text);
		parseEncodings();
	}

	private void parseEncodings() {
		
		Result result;
		while ((result = lexer.nextResult()) != null) {

			if (result.isToken(Token.IDENTIFIER) && result.content().equals("encodings")) {
				result = lexer.nextResult();
				if (result.isToken(Token.COLON)) {
					// result = lexer.nextResult();
					encoding(result);
				}
			} else if (result.isToken(Token.IDENTIFIER) && result.content().equals("size")) {
				
				result = lexer.nextResult();
				if (result.isToken(Token.COLON)) {
					// result = lexer.nextResult();
					size(result);
				}
				
				adjustToScreen();

			} else if (result.isToken(Token.IDENTIFIER) && result.content().equals("element")) {
				// result = lexer.nextResult() ;

				result = lexer.nextResult();
				readElements(result);

			}

			else if (result.isToken(Token.QUOTE)) {
				String[] lines = result.content().split("\n");
				for (int y = 1; y < lines.length - 1; y++) {
					for (int x = 0; x < lines[y].trim().length(); x++) {
						if (lines[y].trim().charAt(x) != ' ') {
							positions.add(new Encoding(Character.toString(lines[y].trim().charAt(x)),new Position(x, y - 1)));
							
							if("TILE".equals(encodings.get(Character.toString(lines[y].trim().charAt(x))))) {
								obstacles.add(new Obstacle("data",encodings.get(Character.toString(lines[y].trim().charAt(x))), new Position(x*xix, (y - 1)*xix), "obstacle",true));
							}else {
								obstacles.add(new Obstacle("data",encodings.get(Character.toString(lines[y].trim().charAt(x))), new Position(x*xix, (y - 1)*xix), "obstacle",false));
							}
							
						}
					}

				}
			}
		}

	}

	public void readElements(Result result) {
		boolean player = false;
		String name = null;
		String skin = null;
		Position pos = null;
		int health = 0;
		Zone zone = null;
		String behavior = null;
		int damage = 0;
		String kind = null;
		List<String> steal = null;
		boolean phantomized = false;
		result = lexer.nextResult();
		while ((result) != null && !result.isToken(Token.LEFT_BRACKET)) {


			switch (result.content().trim()) {

			case "player":
				result = lexer.nextResult();
				result = lexer.nextResult();
				player = Boolean.parseBoolean(result.content());
				result = lexer.nextResult();
				break;

			case "name":
				result = lexer.nextResult();
				result = lexer.nextResult();
				name = result.content();
				result = lexer.nextResult();
				break;

			case "skin":
				result = lexer.nextResult();
				result = lexer.nextResult();

				skin = result.content();

				result = lexer.nextResult();
				break;

			case "position":

				result = lexer.nextResult(); // :
				result = lexer.nextResult(); // (
				String number = "";
				while ((result = lexer.nextResult()) != null && result.isToken(Token.NUMBER)) {
					number = number + result.content();
				}
				int x = Integer.parseInt(number);
				number = "";
				while ((result = lexer.nextResult()) != null && result.isToken(Token.NUMBER)) {
					number = number + result.content();
				}
				int y = Integer.parseInt(number);
				pos = new Position(x*xix, y*xix);
				result = lexer.nextResult();
				break;

			case "health":
				result = lexer.nextResult();

				number = "";
				while ((result = lexer.nextResult()) != null && result.isToken(Token.NUMBER)) {
					number = number + result.content();
				}
				health = Integer.parseInt(number);
				break;

			case "zone":

				result = lexer.nextResult(); // :
				result = lexer.nextResult(); // (
				number = "";
				while ((result = lexer.nextResult()) != null && result.isToken(Token.NUMBER)) {
					number = number + result.content();
				}
				int xx = Integer.parseInt(number);
				number = "";
				while ((result = lexer.nextResult()) != null && result.isToken(Token.NUMBER)) {
					number = number + result.content();
				}
				int yy = Integer.parseInt(number);
				result = lexer.nextResult(); // (
				number = "";
				while ((result = lexer.nextResult()) != null && result.isToken(Token.NUMBER)) {
					number = number + result.content();
				}
				int width = Integer.parseInt(number);
				number = "";
				while ((result = lexer.nextResult()) != null && result.isToken(Token.NUMBER)) {
					number = number + result.content();
				}
				int height = Integer.parseInt(number);
				result = lexer.nextResult(); // (
				zone = new Zone(new Position(xx, yy), width, height);
				result = lexer.nextResult();
				break;

			case "behavior":
				result = lexer.nextResult();
				result = lexer.nextResult();
				behavior = result.content();
				break;

			case "damage":
				result = lexer.nextResult();
				number = "";
				while ((result = lexer.nextResult()) != null && result.isToken(Token.NUMBER)) {
					number = number + result.content();
				}
				damage = Integer.parseInt(number);
				break;

			case "kind":
				result = lexer.nextResult();
				result = lexer.nextResult();
				kind = result.content();
				break;

			case "steal":
				result = lexer.nextResult();
				result = lexer.nextResult();
				steal = parseSteal(result.content());
				break;

			case "phantomized":
				result = lexer.nextResult();
				result = lexer.nextResult();
				phantomized = Boolean.parseBoolean(result.content());
				break;

			default:
				// Handle unknown key if necessary
				result = lexer.nextResult();
				break;
			}

		}

		if (player) {
			playeringame = new Player(name, pos, skin, player, health, phantomized) ;
		} else if ("item".equals(kind)) {
			items.add(new Item(name, skin, pos, kind));
		} else if ("enemy".equals(kind)) {
			enemies.add(new Enemis(name, skin, pos, health, zone, behavior, damage, kind, phantomized));
		} else if ("friend".equals(kind)) {
			friends.add(new Amis(name, skin, pos, health, zone, behavior, damage, kind, steal, phantomized));
		} else if ("obstacle".equals(kind)) {
			if("TILES".equals(skin)) {
				obstacles.add(new Obstacle(name, skin, pos, kind,true));
			}else {
				obstacles.add(new Obstacle(name, skin, pos, kind,false));
			}
			
		}
	}

	private static List<String> parseSteal(String value) {
		String[] parts = value.substring(1, value.length() - 1).split(",");
		List<String> steal = new ArrayList<>();
		for (String part : parts) {
			steal.add(part.trim());
		}
		return steal;
	}

	public void encoding(Result result) {

		while ((result = lexer.nextResult()) != null
				&& !(result.isToken(Token.IDENTIFIER)
						&& (result.content().equals("data") || result.content().equals("size")))
				|| result.isToken(Token.LEFT_BRACKET)) {
			if (result != null && result.isToken(Token.IDENTIFIER) && result.content().matches("[A-Z]+")) {
				String encoding = result.content();
				result = lexer.nextResult();
				if (result != null && result.isToken(Token.LEFT_PARENS)) {

					result = lexer.nextResult();
					if (result != null && result.isToken(Token.IDENTIFIER)) {
						String letter = result.content();
						encodings.put(letter, encoding);
					}
				}
				result = lexer.nextResult();
			}
		}
	}

	public void element(Lexer lex) {
		lexer.nextResult();
	}

	public void size(Result result) {
		while ((result = lexer.nextResult()) != null
				&& !(result.isToken(Token.IDENTIFIER)
						&& (result.content().equals("data") || result.content().equals("encodings")))
				|| result.isToken(Token.LEFT_BRACKET)) {

			if (result != null && result.isToken(Token.LEFT_PARENS)) {
				result = lexer.nextResult();
				if (result != null && result.isToken(Token.NUMBER)) {
					size[0] = result.content();
					result = lexer.nextResult();
					if (result != null && result.isToken(Token.IDENTIFIER) && result.content().matches("x"))
						result = lexer.nextResult();
					if (result != null && result.isToken(Token.NUMBER)) {
						size[1] = result.content();
						sizemap = new Size(Integer.parseInt(size[0]),Integer.parseInt(size[1]));
					}
				}
				result = lexer.nextResult();
				break;
			}
		}
	}

	public void data(Lexer lex) {
		lexer.nextResult();
	}

	public HashMap<String, String> getEncodings() {
		return encodings;
	}

	public String[] getSize() {
		return size;
	}

	public List<Element> getElement() {
		return elements;
	}
	
	
	
	public  int adjustToScreen() {
		Application.run(Color.white, context -> {
		ScreenInfo screenInfo = context.getScreenInfo();
		float width = screenInfo.getWidth();
		float height = screenInfo.getHeight();
		xix = (int) Math.min(width / 7, height / 7);
		});
		return xix;
	}
	
	
	
	public List<Amis> getFriend() {
		return friends;
	}
	public List<Enemis> getEnemy() {
		return enemies;
	}
	public List<Item> getItems() {
		return items;
	}
	public List<Obstacle> getObstacles() {
		return obstacles;
	}
	public Player getPlayer() {
		return playeringame;
	}
	public Size getSizemap() {
		return sizemap;
	}

	
	
	public ArrayList<Encoding> Pion() {
		// ArrayList<Encoding> final_list= new ArrayList<>();
		return positions;
	}


}
