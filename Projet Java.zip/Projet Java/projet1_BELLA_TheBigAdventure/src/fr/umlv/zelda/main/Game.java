package fr.umlv.zelda.main;

import java.awt.Color;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import fr.umlv.zelda.display.Amis;
import fr.umlv.zelda.display.Enemis;
import fr.umlv.zelda.display.GamInDevlop;
import fr.umlv.zelda.display.Item;
import fr.umlv.zelda.display.Obstacle;
import fr.umlv.zelda.display.Player;
import fr.umlv.zelda.lexer.MapReader;
import fr.umlv.zelda.lexer.MapValidator;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.ScreenInfo;

public class Game {
	public static void main(String[] args) throws IOException {
		String mapFileName = null;
		boolean validateOnly = false;
		
		for (int i = 0; i < args.length; i++) {
            if ("--level".equals(args[i]) && i + 1 < args.length) {
                mapFileName = args[i + 1];  
                break;
            }else if ("--validate".equals(args[i]) && mapFileName!= null ) {
                validateOnly = true; // Activer le mode de validation uniquement
            }
        }
		
		Path path = null ;
        if (mapFileName == null) {
        	path = Path.of("maps/monster_house.map");
        }
        
        if (mapFileName != null){
        	path = Path.of(mapFileName);
        }
		
        if (validateOnly) {
        	MapValidator validator = new MapValidator(mapFileName);
    		validator.validate();
        }
        
        
        
		var text = Files.readString(Path.of("maps/monster_house.map"));  
		MapReader mapy = new MapReader(text);
		GamInDevlop game = new GamInDevlop();
		Color myColor = new Color(224, 224, 224);
		Application.run(myColor, context -> {
			List<Item> items = mapy.getItems();
			List<Enemis> enemies = mapy.getEnemy();
			List<Amis> friends = mapy.getFriend();
			List<Obstacle> obstacles = mapy.getObstacles();
			int pace = 0 ;
			int montserpace = 0 ;
			Timer enemyMovementTimer = new Timer();
			TimerTask enemyMovementTask = new TimerTask() {
				@Override
				public void run() {
					game.updateEnemies = true;
				}
			};
			enemyMovementTimer.scheduleAtFixedRate(enemyMovementTask, 0, 100);
			String[] yix = null;
			yix = mapy.getSize();
			ScreenInfo screenInfo = context.getScreenInfo();
			int width = (int) screenInfo.getWidth();
			int height = (int) screenInfo.getHeight();
			int xix = (int) Math.min(width / 7, height / 7);
			int scale = (int) Math.min(width / 7, height / 7);
			pace = xix/15 ;
			montserpace = xix/15 ;
			Player player = mapy.getPlayer() ;
			game.displayMap( context, obstacles, items,enemies,friends,player, xix);
			boolean startcleanup = true ;
			while (true) {
				Event event = context.pollOrWaitEvent(50);
				game.quitGame( context, event);
				if (game.updateEnemies) {
					enemies = game.moveEnemy(context, enemies, obstacles, friends, player, xix,montserpace,width,height); 
					game.updateEnemies = false ;
				}
				if (event != null) {
					player = game.playerMove(context,items,obstacles,friends,enemies,player ,event,xix,pace,width,height,startcleanup);
					startcleanup = false ; 
				}	
			}
		});
	}
}