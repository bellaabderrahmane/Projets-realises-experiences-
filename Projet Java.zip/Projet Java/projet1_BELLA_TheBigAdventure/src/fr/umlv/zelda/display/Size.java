package fr.umlv.zelda.display;

public record Size(int width , int height) {

}
