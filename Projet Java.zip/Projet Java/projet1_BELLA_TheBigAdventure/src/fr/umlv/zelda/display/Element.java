package fr.umlv.zelda.display;

import java.util.List;

public interface Element {

	boolean isPlayer();

	String name();
	
	
	
	String skin();
	Position pos();
	int health();
	Zone zone();
	String behavior();
	int damage();
	String kind();
	List<String> steal();
	boolean phantomized();

	String behaviour();
}
