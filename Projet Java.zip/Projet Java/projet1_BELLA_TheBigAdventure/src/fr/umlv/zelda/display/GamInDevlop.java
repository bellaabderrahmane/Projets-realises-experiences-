package fr.umlv.zelda.display;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JComponent;

import fr.umlv.zelda.lexer.MapReader;
import fr.umlv.zen5.Application;
import fr.umlv.zen5.ApplicationContext;
import fr.umlv.zen5.Event;
import fr.umlv.zen5.Event.Action;
import fr.umlv.zen5.KeyboardKey;
import fr.umlv.zen5.ScreenInfo;

public class GamInDevlop {
	
	public boolean updateEnemies = false;

	
	public enum CardinalDirection {
    NORTH, // Up
    SOUTH, // Down
    EAST,  // Right
    WEST   // Left
	}

	

	private boolean waitForImage(Image image) {
    Component dummyComponent = new Component() {};
    MediaTracker tracker = new MediaTracker(dummyComponent);
    tracker.addImage(image, 0);
    try {
        tracker.waitForAll();
    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        return false;
    }
    return !tracker.isErrorAny();
	}
	
	public void displayObject(String objectskin,Position postion,int picturewidth,Graphics graphics) {
		Image image = Toolkit.getDefaultToolkit().getImage("img/" + objectskin + ".png");
		if (waitForImage(image)) {
			graphics.drawImage(image, postion.x() , postion.y() , picturewidth, picturewidth, null);
	  } else {
	      System.out.println("Image loading failed.");
	  }
	}

	public void displayMap(ApplicationContext context, List<Obstacle> obstacles,List<Item> items,List<Enemis> enemies,List<Amis> friends,Player player, int xix) {
		context.renderFrame(graphics -> {
			displayObject(player.skin(),player.pos(),xix, graphics);
			for (var elm : obstacles) {
				
					displayObject(elm.skin(),elm.pos(),xix, graphics);
				
			}
			for (var elm : items) {
				
					displayObject(elm.skin(),elm.pos(),xix, graphics);
				
			}
			for (var elm : enemies) {
				
					displayObject(elm.skin(),elm.pos(),xix, graphics);
				
			}
			for (var elm : friends) {
				
					displayObject(elm.skin(),elm.pos(),xix, graphics);
				
			}
		});
	}
	
	
	
	
	
	public boolean keepDistance(Position obstacle,Position currentobject,int xix ,CardinalDirection directiontaken) {
		switch (directiontaken) {
	    case NORTH->{
	    	if(((currentobject.x() >= obstacle.x()  && currentobject.x() <= obstacle.x() + xix-1) || ( currentobject.x()+xix >= obstacle.x()+1 && currentobject.x() +xix <= obstacle.x() + xix )) && currentobject.y()  < obstacle.y() + xix && currentobject.y() > obstacle.y() ) {
	    		return false;
	    	}
	    }
	    case SOUTH->{
	    	if( ((currentobject.x() >= obstacle.x()  && currentobject.x() <= obstacle.x() + xix-1) || ( currentobject.x()+xix >= obstacle.x()+1 && currentobject.x() +xix <= obstacle.x() + xix ))  && currentobject.y() + xix > obstacle.y()  && currentobject.y() < obstacle.y()) {
	    		return false;
	    	}
	    }
	    case EAST->{
	    	if(   ((currentobject.y() >= obstacle.y()  && currentobject.y() <= obstacle.y() + xix - 1) || ( currentobject.y()+xix >= obstacle.y() + 1  && currentobject.y() +xix <= obstacle.y() + xix  )) && currentobject.x() + xix > obstacle.x()  && currentobject.x() < obstacle.x()) {
	    		
	    		return false;
	    	}
	    } 
	    case WEST->{
	    	if(   ((currentobject.y() >= obstacle.y()  && currentobject.y() <= obstacle.y() + xix-1) || ( currentobject.y()+xix >= obstacle.y()+1 && currentobject.y() +xix <= obstacle.y() + xix )) && currentobject.x()  < obstacle.x() + xix && currentobject.x() > obstacle.x() )  {
	    		return false;
	    	}
	    }
		}
		
		
		return true ;
	}
	
	
	
	public boolean EntityCanMove(List<Obstacle> obstacles,List<Amis> friends,List<Enemis> enemies,Player player ,int x , int y,int xix,CardinalDirection directiontaken) {

		var futureposition = new Position(player.pos().x()+x, player.pos().y()+y);
		
		for(var s : obstacles ) {
			if(!keepDistance(s.pos(),futureposition, xix , directiontaken) && !s.passable()) {
				return false ;
			}
		}
		for(var s : friends ) {
			if(!keepDistance(s.pos(),futureposition, xix , directiontaken)) {
				return false ;
			}
		}
		for(var s : enemies ) {
			
			if(!keepDistance(s.pos(),futureposition, xix , directiontaken)) {
				
				return false ;
			}
		}
		return true ;
	}
	
	
	/*public void displayMoveEntity(ApplicationContext context,Player player ,int xix,List<Obstacle> obstacles,Position oldposition) {
		context.renderFrame(graphics -> {
			for(var s : obstacles) {
				if(s.pos().equals(oldposition) ) {
					displayObject(s.skin(),oldposition,xix, graphics);
				}
			}
			Color myColor = new Color(224, 224, 224);
			graphics.setColor(myColor);
			graphics.fillRect(oldposition.x(), oldposition.y(), xix, xix);
			displayObject(player.skin(),player.pos(),xix, graphics);
		});
	}*/	
	
	public Player moveEntity(ApplicationContext context,List<Obstacle> obstacles,Player player ,int x , int y,int xix) {
		Position oldposition = player.pos() ;
		player =  new Player(player.name(), new Position(player.pos().x()+x, player.pos().y()+y), player.skin(), player.isPlayer(), player.health(), player.phantomized());
		//displayMoveEntity( context, player , xix,obstacles,oldposition);
		return player ;
	}
	
	
	
	public void updateCenteredMap(ApplicationContext context, List<Obstacle> obstacles,List<Item> items,List<Enemis> enemies,List<Amis> friends,Player player,Player oldplayer, int xix,int width ,int height) {
		context.renderFrame(graphics -> {
			
			cleanUp(graphics, obstacles, items,enemies,friends,oldplayer, xix,width,height);
			
			displayMapAroundPlayer(graphics, obstacles, items,enemies,friends,player, xix,width,height);
		});
	}
	
	public void cleanup(ApplicationContext context,int width ,int height) {
		context.renderFrame(graphics -> {
			Color myColor = new Color(224, 224, 224);
			graphics.setColor(myColor);
			graphics.fillRect(0, 0, width, height);
			
		});
	}
	public Player playerMove(ApplicationContext context,List<Item> items,List<Obstacle> obstacles,List<Amis> friends,List<Enemis> enemies,Player player ,Event event,int xix,int pace,int width ,int height,boolean startcleanup) {
		if (event == null) {
			
			return player; 
		}
		var oldplayer = player ;
		if ( startcleanup) {
			System.out.println("fff");
			cleanup(context,width ,height);
		}
		
		Action action = event.getAction();
		if (action == Action.KEY_PRESSED) {
			switch (event.getKey()) {
			case RIGHT -> {
				if(EntityCanMove(obstacles,friends,enemies,player ,pace ,0,xix,CardinalDirection.EAST)) {
					player =moveEntity(context,obstacles,player ,pace , 0,xix);
					updateCenteredMap(context, obstacles, items,enemies,friends,player,oldplayer, xix,width,height);
				}
			}
			case LEFT -> {
				if(EntityCanMove(obstacles,friends,enemies,player ,-pace , 0,xix,CardinalDirection.WEST)) {
				player = moveEntity(context,obstacles,player ,-pace , 0,xix);
				updateCenteredMap(context, obstacles, items,enemies,friends,player,oldplayer, xix,width,height);}
			}
			case UP -> {
				if(EntityCanMove(obstacles,friends,enemies,player ,0 , -pace,xix,CardinalDirection.NORTH)) {
				player = moveEntity(context,obstacles,player ,0 , -pace,xix);
				updateCenteredMap(context, obstacles, items,enemies,friends,player,oldplayer, xix,width,height);}
			}
			case DOWN -> {
				if(EntityCanMove(obstacles,friends,enemies,player ,0 , pace,xix,CardinalDirection.SOUTH)) {
				player = moveEntity(context,obstacles,player ,0 , pace,xix);
				updateCenteredMap(context, obstacles, items,enemies,friends,player,oldplayer, xix,width,height);}
			}
			default -> xix = xix;
			}
		}
		return player ;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public  CardinalDirection getRandomDirection() {
    Random random = new Random();
    CardinalDirection[] directions = CardinalDirection.values();
    return directions[random.nextInt(directions.length)];
}
	
	public void displayMoveEnemy(Graphics graphics,Enemis enemy ,int xix,List<Obstacle> obstacles,Position oldposition) {
			for(var s : obstacles) {
				if(s.pos().equals(oldposition) ) {
					displayObject(s.skin(),oldposition,xix, graphics);
				}
			}
			Color myColor = new Color(224, 224, 224);
			graphics.setColor(myColor);
			graphics.fillRect(oldposition.x(), oldposition.y(), xix, xix);
			displayObject(enemy.skin(),enemy.pos(),xix, graphics);
	}	
	
	
	public boolean EnemyCanMove(List<Obstacle> obstacles,List<Amis> friends,List<Enemis> enemies,Enemis enemy ,Player player ,int x , int y,int xix,CardinalDirection directiontaken) {
		
		if(!inVicinity(player.pos(),enemy.pos(),xix) ) {
			return false;
		}
		
		var futureposition = new Position(enemy.pos().x()+x, enemy.pos().y()+y);
		if(!keepDistance(player.pos(),futureposition, xix , directiontaken)) {
			return false ;
		}
		if(enemy.behavior() == null ) {
			return false ;
		}
		
		for(var s : obstacles ) {
			if(!keepDistance(s.pos(),futureposition, xix , directiontaken) && !s.passable()) {
				return false ;
			}
		}
		for(var s : friends ) {
			if(!keepDistance(s.pos(),futureposition, xix , directiontaken)) {
				return false ;
			}
		}
		for(var s : enemies ) {
			if(!keepDistance(s.pos(),futureposition, xix , directiontaken)) {
				return false ;
			}
		}
		return true ;
	}
	
	
  public  int randomMovePaceX(CardinalDirection direction,int pace) {
  	if(direction == CardinalDirection.WEST || direction == CardinalDirection.EAST) {
  		switch (direction) {
				case WEST -> {
					return -pace ;
				}
				case EAST -> {
					return pace ;
				}
  		}
  	}
  	return 0 ;
  }
  
  
  
  public  int randomMovePaceY(CardinalDirection direction,int pace) {

  	if(direction == CardinalDirection.NORTH || direction == CardinalDirection.SOUTH) {
  		switch (direction) {
				case NORTH -> {
					return -pace ;
				}
				case SOUTH -> {
					return pace ;
				}
  		}
  	}
  	return 0 ;
  }
  
  


  
	
	public List<Enemis> moveEnemy(ApplicationContext context,List<Enemis> enemies,List<Obstacle> obstacles,List<Amis> friends,Player player ,int xix,int monsterpace,int width , int height) {
		context.renderFrame(graphics -> {
		for (int i = 0; i < enemies.size(); i++) {
      Enemis enemy = enemies.get(i);
      Enemis movedenemy = enemy;
  		CardinalDirection direction = getRandomDirection();
  		int x = randomMovePaceX( direction, monsterpace);
  		int y = randomMovePaceY( direction, monsterpace);
  		//System.out.println("x , y = " + x + " , " + y);
  		if(EnemyCanMove(obstacles,friends,enemies,enemy,player ,x ,y,xix,direction)) {
  			var newposition = new Position( enemy.pos().x() + x , enemy.pos().y() + y );
  			var oldposition = drawVisually( player.pos() ,enemy.pos(), xix,width,height);
  			Color myColor = new Color(224, 224, 224);
  			graphics.setColor(myColor);
  			graphics.fillRect(oldposition.x(), oldposition.y(), xix, xix);
  		  movedenemy = new Enemis(enemy.name(),enemy.skin(),newposition,enemy.health(),enemy.zone(),enemy.behavior(),enemy.damage(),enemy.kind(),enemy.phantomized());  		  
				displayObject(enemy.skin(),drawVisually( player.pos() ,movedenemy.pos(), xix,width,height),xix, graphics);
  		}
      enemies.set(i, movedenemy); // Update the list with the new enemy object
		}
		});
		return enemies ;
	}
	
	
	

	
	
	
	
	
	
	
	
	
	
	public void cleanUp(Graphics graphics, List<Obstacle> obstacles,List<Item> items,List<Enemis> enemies,List<Amis> friends,Player player, int xix,int width ,int height) {
		
			Color myColor = new Color(224, 224, 224);
			graphics.setColor(myColor);
			Position objectposition ;
			for (var elm : obstacles) {
				if(inVicinity(player.pos(), elm.pos(),xix) ) {
					objectposition = drawVisually( player.pos() ,elm.pos(), xix,width,height);
					graphics.fillRect(objectposition.x(), objectposition.y(), xix, xix);
				}
			}
			for (var elm : items) {
				if(inVicinity(player.pos(), elm.pos(),xix) ) {
					objectposition =drawVisually( player.pos() ,elm.pos(), xix,width,height);
					graphics.fillRect(objectposition.x(), objectposition.y(), xix, xix);
				}
			}
			for (var elm : enemies) {
				if(inVicinity(player.pos(), elm.pos(),xix) ) {
					objectposition =drawVisually( player.pos() ,elm.pos(), xix,width,height);
					graphics.fillRect(objectposition.x(), objectposition.y(), xix, xix);
				}
			}
			for (var elm : friends) {
				if(inVicinity(player.pos(), elm.pos(),xix) ) {
					objectposition =drawVisually( player.pos() ,elm.pos(), xix,width,height);
					graphics.fillRect(objectposition.x(), objectposition.y(), xix, xix);
				}
			}
		
	}
	
	
	
	
	public void displayMapAroundPlayer(Graphics graphics, List<Obstacle> obstacles,List<Item> items,List<Enemis> enemies,List<Amis> friends,Player player, int xix,int width ,int height) {
		
			var playerposition = new Position(width/2,height/2);
			Color myColor = new Color(224, 224, 224);
			graphics.setColor(myColor);
			
			Position objectposition ;
			for (var elm : obstacles) {
				if(inVicinity(player.pos(), elm.pos(),xix) ) {
					objectposition = drawVisually( player.pos() ,elm.pos(), xix,width,height);
					displayObject(elm.skin(),objectposition,xix, graphics);
				}
			}
			for (var elm : items) {
				if(inVicinity(player.pos(), elm.pos(),xix) ) {
					objectposition =drawVisually( player.pos() ,elm.pos(), xix,width,height);
					displayObject(elm.skin(),objectposition,xix, graphics);
				}
			}
			for (var elm : enemies) {
				if(inVicinity(player.pos(), elm.pos(),xix) ) {
					objectposition =drawVisually( player.pos() ,elm.pos(), xix,width,height);
					displayObject(elm.skin(),objectposition,xix, graphics);
				}
			}
			for (var elm : friends) {
				if(inVicinity(player.pos(), elm.pos(),xix) ) {
					objectposition =drawVisually( player.pos() ,elm.pos(), xix,width,height);
					displayObject(elm.skin(),objectposition,xix, graphics);
				}
			}
			displayObject(player.skin(),playerposition,xix, graphics);
		
	}
	
	
	
	
	
	
	
	
	
	public Position drawVisually(Position player, Position object, int xix, int width, int height) {
    int halfViewportWidth = (width / 2) ; // Adjusted for player position in the center
    int halfViewportHeight = (height / 2) ; // Adjusted for player position in the center

    // Calculate the top-left position of the viewport in the game world
    int viewportLeftX = player.x() - halfViewportWidth;
    int viewportTopY = player.y() - halfViewportHeight;

    // Calculate the object's position relative to the viewport
    int newObjectX = object.x() - viewportLeftX;
    int newObjectY = object.y() - viewportTopY;

    return new Position(newObjectX, newObjectY);
}

	
	
	
	
	public boolean inVicinity(Position player ,Position object,int xix) {
    // Calculate half of the width to find the bounds of the square
    int halfWidth = (14*xix) / 2;
    // Calculate the top-left and bottom-right coordinates of the square
    int leftX = player.x() - halfWidth;
    int rightX = player.x() + halfWidth;
    int topY = player.y() - halfWidth;
    int bottomY = player.y() + halfWidth;
    // Check if the object is within the bounds of the square
    return object.x() >= leftX && object.x() <= rightX && object.y() >= topY && object.y() <= bottomY;
	}
	
	public void quitGame(ApplicationContext context,Event event) {
		if (event == null) {
			return; 
		}
		Action action = event.getAction();
		if ((action == Action.KEY_PRESSED && event.getKey() == KeyboardKey.Q) ) {
			System.out.println("Touche Q appuyée, sortie de l'application");
			context.exit(0);
			return;
		}
	}
	

	public static void main(String[] args) throws IOException {

		var text = Files.readString(Path.of("maps/test.map"));  //monster_house
		MapReader mapy = new MapReader(text);
		GamInDevlop game = new GamInDevlop();
		Color myColor = new Color(224, 224, 224);
		Application.run(myColor, context -> {
			List<Item> items = mapy.getItems();
			List<Enemis> enemies = mapy.getEnemy();
			List<Amis> friends = mapy.getFriend();
			List<Obstacle> obstacles = mapy.getObstacles();
			int pace = 0 ;
			int montserpace = 0 ;
			Timer enemyMovementTimer = new Timer();
			TimerTask enemyMovementTask = new TimerTask() {
				@Override
				public void run() {
					game.updateEnemies = true;
				}
			};
			enemyMovementTimer.scheduleAtFixedRate(enemyMovementTask, 0, 100);
			String[] yix = null;
			yix = mapy.getSize();
			ScreenInfo screenInfo = context.getScreenInfo();
			int width = (int) screenInfo.getWidth();
			int height = (int) screenInfo.getHeight();
			int xix = (int) Math.min(width / 7, height / 7);
			int scale = (int) Math.min(width / 7, height / 7);
			pace = xix/15 ;
			montserpace = xix/15 ;
			Player player = mapy.getPlayer() ;
			game.displayMap( context, obstacles, items,enemies,friends,player, xix);
			boolean startcleanup = true ;
			while (true) {
				
				Event event = context.pollOrWaitEvent(50);
				game.quitGame( context, event);
				if (game.updateEnemies) {
					enemies = game.moveEnemy(context, enemies, obstacles, friends, player, xix,montserpace,width,height); 
					game.updateEnemies = false ;
				}
				if (event != null) {
					player = game.playerMove(context,items,obstacles,friends,enemies,player ,event,xix,pace,width,height,startcleanup);
					startcleanup = false ; 
				}
				
			}
			
			
		});
		
	}
}