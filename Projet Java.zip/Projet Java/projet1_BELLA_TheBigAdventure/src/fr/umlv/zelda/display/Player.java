package fr.umlv.zelda.display;

import java.util.List;
import java.util.Objects;

public record Player(String name, Position pos, String skin, boolean player, int health, boolean phantomized)
		implements Element {

	public Player {
		Objects.requireNonNull(name);

	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public String skin() {
		// TODO Auto-generated method stub
		return skin;
	}

	@Override
	public boolean isPlayer() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Zone zone() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String behavior() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int damage() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String kind() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> steal() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String behaviour() {
		// TODO Auto-generated method stub
		return null;
	}

}
