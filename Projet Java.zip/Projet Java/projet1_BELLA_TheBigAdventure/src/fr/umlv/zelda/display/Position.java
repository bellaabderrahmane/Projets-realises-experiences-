package fr.umlv.zelda.display;

public record Position(int x, int y) {

}
