package fr.umlv.zelda.display;

import java.util.List;
import java.util.Objects;

public record Enemis(String name, String skin, Position pos, int health, Zone zone, String behavior, int damage,
		String kind, boolean phantomized) implements Element {

	public Enemis {
		Objects.requireNonNull(name);
		Objects.requireNonNull(skin);
		Objects.requireNonNull(kind);
	}

	@Override
	public boolean isPlayer() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<String> steal() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String name() {
		// TODO Auto-generated method stub
		return name;
	}

	
	@Override
	public String skin() {
		// TODO Auto-generated method stub
		return skin;
	}

	
	@Override
	public Zone zone() {
		// TODO Auto-generated method stub
		return zone;
	}
	
	@Override
	public String kind() {
		// TODO Auto-generated method stub
		return kind;
	}
	
	@Override
	public String behaviour() {
		// TODO Auto-generated method stub
		return behavior;
	}


}