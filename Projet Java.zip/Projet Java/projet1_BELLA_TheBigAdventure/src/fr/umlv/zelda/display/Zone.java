package fr.umlv.zelda.display;

public record Zone(Position position, int width, int height) {
	
}
