package fr.umlv.zelda.display;

public record Encoding(String name, Position pos) {
}

