package fr.umlv.zelda.display;

import java.util.List;
import java.util.Objects;

public record Item(String name, String skin, Position pos, String kind) implements Element {
	public Item {
		Objects.requireNonNull(name);
		Objects.requireNonNull(skin);
		Objects.requireNonNull(kind);

	}

	@Override
	public boolean isPlayer() {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public int health() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Zone zone() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String behavior() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int damage() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<String> steal() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean phantomized() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String behaviour() {
		// TODO Auto-generated method stub
		return null;
	}

}
