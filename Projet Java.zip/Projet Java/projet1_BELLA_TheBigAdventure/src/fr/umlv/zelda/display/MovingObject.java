package fr.umlv.zelda.display;

public class MovingObject {
/*
	public MovingObject() {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
*/
}
