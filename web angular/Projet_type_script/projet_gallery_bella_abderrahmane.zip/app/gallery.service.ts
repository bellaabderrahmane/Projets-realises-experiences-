import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, Observable, of } from 'rxjs';
import { GetUserImagesResponse, Image, ImageCreation } from './model/image';

@Injectable({
  providedIn: 'root',
})
export class GalleryService {
  private apiBaseUrl: string =
    'https://europe-west1-cours-angular-263913.cloudfunctions.net/messenger/api/images';
  constructor(private httpClient: HttpClient) {}

  getUserImages(username: string): Observable<Image[]> {
    return this.httpClient
      .get<GetUserImagesResponse>(this.apiBaseUrl + '/' + username)
      .pipe(map((reponse) => reponse.images));
  }

  deleteImage(username: string, imageId: string): Observable<boolean> {
    return this.httpClient
      .delete<Image>(this.apiBaseUrl + '/' + username + '/' + imageId)
      .pipe(
        map((reponse) => true),
        catchError((err) => {
          console.log(err);
          return of(false);
        })
      );
  }

  addImage(
    username: string,
    imageCreation: ImageCreation
  ): Observable<boolean> {
    return this.httpClient
      .post<Image>(this.apiBaseUrl + '/' + username, imageCreation)
      .pipe(
        map((image) => true),
        catchError((err) => {
          console.log(err);
          return of(false);
        })
      );
  }
}
