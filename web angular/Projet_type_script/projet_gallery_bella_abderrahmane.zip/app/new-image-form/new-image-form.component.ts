import { Component, EventEmitter, Output } from '@angular/core';
import { ImageCreation } from '../model/image';

@Component({
  selector: 'app-new-image-form',
  templateUrl: './new-image-form.component.html',
  styleUrls: ['./new-image-form.component.css'],
})
export class NewImageFormComponent {
  imageType: string = 'png'; //We set the selectbox to png by default
  imageContent: string = '';

  @Output()
  addImageEvent = new EventEmitter<ImageCreation>();

  addImage() {
    let imageCreation: ImageCreation = {
      type: this.imageType,
      content: this.imageContent,
    };
    this.addImageEvent.emit(imageCreation);
    this.imageContent = '';
  }
}
