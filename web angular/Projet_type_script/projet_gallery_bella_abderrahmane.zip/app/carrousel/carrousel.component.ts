import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Image } from '../model/image';

@Component({
  selector: 'app-carrousel',
  templateUrl: './carrousel.component.html',
  styleUrls: ['./carrousel.component.css'],
})
export class CarrouselComponent {
  @Input()
  image: Image;

  @Output()
  deleteImageEvent = new EventEmitter<string>();
}
