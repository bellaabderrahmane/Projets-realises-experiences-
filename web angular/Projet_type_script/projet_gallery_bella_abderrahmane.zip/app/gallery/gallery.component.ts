import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GalleryService } from '../gallery.service';
import { Image, ImageCreation } from '../model/image';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css'],
})
export class GalleryComponent implements OnInit {
  images: Image[];
  username: string;

  constructor(
    private galleryService: GalleryService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.username = this.route.snapshot.paramMap.get('username');
    this.fetchImages();
  }

  fetchImages() {
    this.galleryService
      .getUserImages(this.username)
      .subscribe((images) => (this.images = images));
  }

  addImage(imageCreation: ImageCreation) {
    this.galleryService
      .addImage(this.username, imageCreation)
      .subscribe((added) => {
        if (added) {
          this.fetchImages();
        }
      });
  }

  deleteImage(imageId: string) {
    this.galleryService
      .deleteImage(this.username, imageId)
      .subscribe((deleted) => {
        if (deleted) {
          this.fetchImages();
        }
      });
  }
}
