import { Component, input, output, signal } from '@angular/core';
import { Todo } from '../model/todo';
import { NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-todo-item',
  imports: [NgClass, FormsModule],
  templateUrl: './todo-item.html',
  styleUrl: './todo-item.css',
})
export class TodoItem {

  todo = input.required<Todo>()
  editMode = signal(false)
  label = signal('')
  labelUpdated = output<string>()
  statusUpdated = output<boolean>()


  todoLabelUpdated() {
      this.labelUpdated.emit(this.label())
      this.label.set('')
  }

  switchTodoStatus() {
    this.statusUpdated.emit(!this.todo().done)
  }
}
