import { Component, computed, linkedSignal, signal, WritableSignal } from '@angular/core';
import { Todo } from '../model/todo';
import { FormsModule } from '@angular/forms';
import { TodoItem } from '../todo-item/todo-item';

@Component({
  selector: 'app-todolist',
  imports: [FormsModule, TodoItem],
  templateUrl: './todolist.html',
  styleUrl: './todolist.css',
})
export class Todolist {

  public labelValue = signal('')

  public todos : WritableSignal<Todo[]> = signal([
    {label: 'Todo 1', done: true},
    {label: 'Todo 3', done: true},
    {label: 'Todo 2', done: false}
  ])

  setStatus(status: boolean, index : number) {
    this.todos.update(todos => {
      todos[index].done = status
      todos.sort((a,b) => a.done == b.done ? a.label.localeCompare(b.label) : a.done ? 1 : -1)
      return todos
    })
  }

  updateLabel(newLabel: string, index : number) {
    this.todos.update(todos => {
      todos[index].label = newLabel
      
      return todos
    })
  }

  addTodo() {
    this.todos.update(todos => {
      todos.push({label: this.labelValue(), done: false})
      this.labelValue.set('')
      return todos
    })
  }
}
