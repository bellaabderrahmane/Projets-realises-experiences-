import { Component, signal, WritableSignal } from '@angular/core';
import { Todo } from '../model/todo';
import { NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-todolist',
  imports: [NgClass, FormsModule],
  templateUrl: './todolist.html',
  styleUrl: './todolist.css',
})
export class Todolist {

  public labelValue = signal('')

  public todos : WritableSignal<Todo[]> = signal([
    {label: 'Todo 1', done: true},
    {label: 'Todo 2', done: false}
  ])

  setDone(todo: Todo, index: number) {
    this.todos.update(todos => {
      todos[index].done = !todos[index].done
      return todos
    })
  }

  addTodo() {
    this.todos.update(todos => {
      todos.push({label: this.labelValue(), done: false})
      this.labelValue.set('')
      return todos
    })
  }
}
