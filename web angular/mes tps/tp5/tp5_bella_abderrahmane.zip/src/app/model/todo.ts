export interface TodoResponse {
	todos : Todo[];
}


export interface CreateTodo {
	label: string
}

export interface UpdateTodo {
	label: string;
	done: boolean
}

export interface Todo {
  id: string;
  label: string;
  done: boolean;
  creationDate: number;
}