import { Injectable, inject } from '@angular/core';
import { Todo, TodoResponse } from './model/todo';
import { Observable, catchError, map, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  private static DELAY : number = 2000;

  private baseUrl = "https://europe-west1-cours-angular-263913.cloudfunctions.net/todoapp/todo"
  private httpClient = inject(HttpClient)

  getTodos(): Observable<Todo[]> {
    return this.httpClient.get<TodoResponse>(`${this.baseUrl}?delay=${TodoService.DELAY}`).pipe(
      map(res => res.todos)
    )
  }

  createTodo(label: string): Observable<boolean> {
    return this.httpClient.post<Todo>(this.baseUrl, {
      label: label
    }).pipe(
      map(res => true),
      catchError(err => of(false))
    )
  }

  updateTodo(todo: Todo): Observable<boolean> {
    return this.httpClient.put<Todo>(`${this.baseUrl}/${todo.id}`, {
      label: todo.label,
      done: todo.done
    }).pipe(
      map(res => true),
      catchError(err => of(false))
    )
  }

  deleteTodo(id: string): Observable<boolean> {
    return this.httpClient.delete(`${this.baseUrl}/${id}`).pipe(
      map(res => true),
      catchError(err => of(false))
    )
  }

}
