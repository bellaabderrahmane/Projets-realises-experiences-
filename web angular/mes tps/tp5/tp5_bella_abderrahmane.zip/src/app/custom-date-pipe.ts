import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customDate',
})
export class CustomDatePipe implements PipeTransform {

  transform(value: number, withHour: boolean = false): string {
    let date = new Date(value);
    let result = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`
    if (withHour) {
      result += ` ${date.getHours()}:${date.getMinutes()}`
    }
    return result;
  }

}
