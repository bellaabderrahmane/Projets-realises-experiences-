import { Component, computed, inject, linkedSignal, signal, WritableSignal } from '@angular/core';
import { Todo } from '../model/todo';
import { FormsModule } from '@angular/forms';
import { TodoItem } from '../todo-item/todo-item';
import { TodoService } from '../todo-service';

@Component({
  selector: 'app-todolist',
  imports: [FormsModule, TodoItem],
  templateUrl: './todolist.html',
  styleUrl: './todolist.css',
})
export class Todolist {

  public labelValue = signal('')
  public loading = signal(false)

  public todos : WritableSignal<Todo[]> = signal([])
  private todoService: TodoService = inject(TodoService)


  ngOnInit() {
    this.loading.set(true)
    this.fetchTodos();
  }

  fetchTodos() {
    this.todoService.getTodos().subscribe(todos => {
      this.todos.set(todos)
      this.loading.set(false)
    })
  }

  deleteTodo(index : number) {
    this.loading.set(true)
    this.todoService.deleteTodo(this.todos()[index].id).subscribe(res => {
      if (res) {
        this.fetchTodos();
      }
    })
  }

  setStatus(status: boolean, index : number) {
    this.loading.set(true)
    this.todoService.updateTodo({...this.todos()[index], done: status}).subscribe(res => {
      if (res) {
        this.fetchTodos();
      }
    })
  }

  updateLabel(newLabel: string, index : number) {
    this.loading.set(true)
    this.todoService.updateTodo({...this.todos()[index], label: newLabel}).subscribe(res => {
      if (res) {
        this.fetchTodos();
      }
    })
  }

  addTodo() {
    this.loading.set(true)
    this.todoService.createTodo(this.labelValue()).subscribe(res => {
      if (res) {
        this.labelValue.set('')
        this.fetchTodos();
      }
    })    
  }
}
