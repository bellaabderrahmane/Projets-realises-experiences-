import { Injectable } from '@angular/core';
import { Todo } from './model/todo';

@Injectable({
  providedIn: 'root',
})
export class TodoService {

  private todos : Todo[] = [
    {id: 1, label: 'Todo 1', done: true, creationDate: new Date().valueOf()},
    {id: 2, label: 'Todo 3', done: true, creationDate: new Date().valueOf()},
  ]

  getTodos() : Todo[] {
    return [...this.todos]
  }

  createTodo(label : string) : void {
    this.todos.push({id: Math.floor(Math.random() * 1000), label: label, done: false, creationDate: new Date().valueOf()})
  }

  updateTodo(todo : Todo) : void {
    let todoIndex = this.todos.findIndex(t => t.id == todo.id)
    this.todos[todoIndex] = todo
  }
  
}
