import { Component, computed, inject, linkedSignal, signal, WritableSignal } from '@angular/core';
import { Todo } from '../model/todo';
import { FormsModule } from '@angular/forms';
import { TodoItem } from '../todo-item/todo-item';
import { TodoService } from '../todo-service';

@Component({
  selector: 'app-todolist',
  imports: [FormsModule, TodoItem],
  templateUrl: './todolist.html',
  styleUrl: './todolist.css',
})
export class Todolist {

  public labelValue = signal('')

  public todos : WritableSignal<Todo[]> = signal([])
  private todoService: TodoService = inject(TodoService)

  ngOnInit() {
    this.todos.set(this.todoService.getTodos());
  }

  setStatus(status: boolean, index : number) {
    this.todoService.updateTodo({...this.todos()[index], done: status})
    this.todos.set(this.todoService.getTodos());
  }

  updateLabel(newLabel: string, index : number) {
    this.todoService.updateTodo({...this.todos()[index], label: newLabel})
    this.todos.set(this.todoService.getTodos());
  }

  addTodo() {
    this.todoService.createTodo(this.labelValue())
    this.labelValue.set('')
    this.todos.set(this.todoService.getTodos());
  }
}
